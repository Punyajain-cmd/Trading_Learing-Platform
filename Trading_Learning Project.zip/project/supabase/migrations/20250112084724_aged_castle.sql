/*
  # Add trading positions table
  
  1. New Tables
    - `trading_positions`
      - `id` (uuid, primary key)
      - `event_id` (uuid, references trading_events)
      - `user_id` (uuid, references users)
      - `crypto_symbol` (text)
      - `amount` (numeric)
      - `entry_price` (numeric)
      - `created_at` (timestamptz)
      - Unique constraint on (event_id, user_id, crypto_symbol)

  2. Security
    - Enable RLS on `trading_positions` table
    - Add policies for authenticated users to:
      - Read their own positions
      - Insert new positions
      - Update their positions
      - Delete their positions
*/

-- Create trading positions table
CREATE TABLE public.trading_positions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES trading_events(id),
  user_id uuid REFERENCES users(id),
  crypto_symbol text NOT NULL,
  amount numeric NOT NULL,
  entry_price numeric NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(event_id, user_id, crypto_symbol)
);

-- Enable RLS
ALTER TABLE trading_positions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read their own positions"
  ON trading_positions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own positions"
  ON trading_positions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own positions"
  ON trading_positions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own positions"
  ON trading_positions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX trading_positions_user_event_idx ON trading_positions(user_id, event_id);
CREATE INDEX trading_positions_crypto_symbol_idx ON trading_positions(crypto_symbol);
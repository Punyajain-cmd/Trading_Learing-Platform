/*
  # Add Portfolio Tables

  1. New Tables
    - `portfolio_assets`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references users)
      - `crypto_symbol` (text)
      - `amount` (numeric)
      - `avg_buy_price` (numeric)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `portfolio_assets`
    - Add policies for authenticated users to manage their portfolio
*/

-- Create portfolio assets table
CREATE TABLE public.portfolio_assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  crypto_symbol text NOT NULL,
  amount numeric NOT NULL,
  avg_buy_price numeric NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, crypto_symbol)
);

-- Enable RLS
ALTER TABLE portfolio_assets ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own portfolio assets"
  ON portfolio_assets
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create portfolio assets"
  ON portfolio_assets
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their portfolio assets"
  ON portfolio_assets
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their portfolio assets"
  ON portfolio_assets
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes
CREATE INDEX portfolio_assets_user_id_idx ON portfolio_assets(user_id);
CREATE INDEX portfolio_assets_symbol_idx ON portfolio_assets(crypto_symbol);
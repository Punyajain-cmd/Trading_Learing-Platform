/*
  # Create watchlist table

  1. New Tables
    - `watchlist`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `crypto_id` (text, not null)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `watchlist` table
    - Add policies for authenticated users to manage their watchlist
*/

-- Create watchlist table
CREATE TABLE public.watchlist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  crypto_id text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, crypto_id)
);

-- Enable RLS
ALTER TABLE watchlist ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own watchlist"
  ON watchlist
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can add to their watchlist"
  ON watchlist
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove from their watchlist"
  ON watchlist
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes
CREATE INDEX watchlist_user_id_idx ON watchlist(user_id);
CREATE INDEX watchlist_crypto_id_idx ON watchlist(crypto_id);
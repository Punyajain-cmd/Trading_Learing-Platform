/*
  # Update First Four Events

  1. Changes
    - Reset and update the first 4 events with specific themes and coins
    - Ensure proper coin support for trading interface
    - Set all events to upcoming status
    
  2. Notes
    - Maintains existing event structure
    - Updates theme_id for proper coin integration
    - Preserves other event data
*/

-- Update the first 4 events with specific themes and descriptions
WITH events_to_update AS (
  SELECT id
  FROM trading_events
  ORDER BY start_time
  LIMIT 4
)
UPDATE trading_events
SET 
  title = CASE
    WHEN row_number = 1 THEN 'DeFi Masters Challenge'
    WHEN row_number = 2 THEN 'Layer 1 Champions League'
    WHEN row_number = 3 THEN 'Metaverse Trading Cup'
    WHEN row_number = 4 THEN 'Scaling Solutions Derby'
  END,
  description = CASE
    WHEN row_number = 1 THEN 'Master DeFi trading with popular tokens like UNI, AAVE, and COMP. Learn yield farming strategies and earn rewards!'
    WHEN row_number = 2 THEN 'Trade major blockchain platforms like ETH, SOL, and ADA. Predict which Layer 1 will dominate the future!'
    WHEN row_number = 3 THEN 'Enter the virtual world of trading with MANA, SAND, and other metaverse tokens. Experience the future of digital assets!'
    WHEN row_number = 4 THEN 'Focus on Layer 2 and scaling solutions like MATIC, OP, and ARB. Trade the future of blockchain scalability!'
  END,
  theme_id = CASE
    WHEN row_number = 1 THEN 'defi-trading'
    WHEN row_number = 2 THEN 'layer1-battle'
    WHEN row_number = 3 THEN 'metaverse-gaming'
    WHEN row_number = 4 THEN 'scaling-solutions'
  END,
  start_time = NOW() + (row_number * INTERVAL '3 hours'),
  end_time = NOW() + INTERVAL '7 days' + (row_number * INTERVAL '3 hours'),
  status = 'upcoming'
FROM (
  SELECT id, ROW_NUMBER() OVER (ORDER BY start_time) as row_number
  FROM trading_events
  WHERE id IN (SELECT id FROM events_to_update)
) subquery
WHERE trading_events.id = subquery.id;
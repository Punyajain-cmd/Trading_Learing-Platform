/*
  # Add active crypto trading event

  1. New Data
    - Adds an active crypto trading event that starts immediately
    - Event includes ₹10 Lakh initial balance for trading
    
  2. Changes
    - Inserts new active event into trading_events table
*/

INSERT INTO trading_events (title, description, start_time, end_time, max_participants, initial_balance, status)
VALUES
  (
    'Live Crypto Trading Challenge',
    'Start trading cryptocurrencies right now! Use your ₹10 Lakh virtual money to trade Bitcoin, Ethereum, and other popular cryptocurrencies. Learn real-time trading strategies and compete with other traders.',
    NOW(),
    NOW() + INTERVAL '7 days',
    1000,
    1000000,
    'active'
  );
/*
  # Add relationships between trading positions and event participants

  1. Changes
    - Add composite unique constraint on event_participants
    - Add foreign key relationship between trading_positions and event_participants
    - Add index for better query performance
*/

-- First add composite unique constraint to event_participants
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'event_participants_event_user_key'
  ) THEN
    ALTER TABLE event_participants 
    ADD CONSTRAINT event_participants_event_user_key 
    UNIQUE (event_id, user_id);
  END IF;
END $$;

-- Then add the foreign key relationship
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'trading_positions_event_participant_fk'
  ) THEN
    ALTER TABLE trading_positions
    ADD CONSTRAINT trading_positions_event_participant_fk
    FOREIGN KEY (event_id, user_id)
    REFERENCES event_participants(event_id, user_id)
    ON DELETE CASCADE;
  END IF;
END $$;

-- Add composite index for better performance
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'trading_positions_event_user_idx'
  ) THEN
    CREATE INDEX trading_positions_event_user_idx 
    ON trading_positions(event_id, user_id);
  END IF;
END $$;
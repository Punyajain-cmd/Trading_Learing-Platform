/*
  # Add phone verification support

  1. New Columns
    - `phone_number` (text, unique)
    - `phone_verified` (boolean)
    - `verification_code` (text)
    - `verification_code_expires_at` (timestamptz)

  2. Security
    - Enable RLS on users table
    - Add policies for phone verification
*/

ALTER TABLE users
ADD COLUMN IF NOT EXISTS phone_number text UNIQUE,
ADD COLUMN IF NOT EXISTS phone_verified boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS verification_code text,
ADD COLUMN IF NOT EXISTS verification_code_expires_at timestamptz;

-- Update existing policies
CREATE POLICY "Users can update their phone verification"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Create index for phone lookups
CREATE INDEX IF NOT EXISTS users_phone_number_idx ON users(phone_number);
/*
  # Fix event participants policies

  1. Changes
    - Add RLS policies for event_participants table to allow:
      - Inserting new participations
      - Reading own participations
      - Updating own participations
      
  2. Security
    - Only authenticated users can participate
    - Users can only view and update their own participations
*/

-- Allow authenticated users to insert new participations
CREATE POLICY "Users can join events"
ON event_participants
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Allow users to read their own participations
CREATE POLICY "Users can view their participations"
ON event_participants
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- Allow users to update their own participations
CREATE POLICY "Users can update their participations"
ON event_participants
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);
/*
  # Update Event Statuses

  1. Changes
    - Set all events to 'upcoming' status
    - Update start times to begin from tomorrow
    - Update end times to be 7 days after start time
    
  2. Notes
    - Preserves existing event data
    - Maintains theme_id and other fields
    - Staggers event start times for better distribution
*/

-- Update all events to upcoming status and adjust times
WITH numbered_events AS (
  SELECT 
    id,
    ROW_NUMBER() OVER (ORDER BY start_time) as row_num
  FROM trading_events
)
UPDATE trading_events
SET 
  start_time = NOW() + INTERVAL '1 day' + (SELECT row_num * INTERVAL '2 hours' FROM numbered_events WHERE numbered_events.id = trading_events.id),
  end_time = NOW() + INTERVAL '8 days' + (SELECT row_num * INTERVAL '2 hours' FROM numbered_events WHERE numbered_events.id = trading_events.id),
  status = 'upcoming';
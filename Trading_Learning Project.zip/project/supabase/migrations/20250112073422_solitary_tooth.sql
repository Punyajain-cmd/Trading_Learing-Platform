/*
  # Add sample trading events

  1. New Data
    - Adds sample trading events with different statuses and time periods
    - Events include different prize pools and participant limits
    
  2. Changes
    - Inserts initial data into trading_events table
*/

INSERT INTO trading_events (title, description, start_time, end_time, max_participants, initial_balance, status)
VALUES
  (
    'Crypto Trading Challenge',
    'Test your crypto trading skills with ₹10 Lakh virtual money. Trade popular cryptocurrencies and compete for the top spot!',
    NOW() + INTERVAL '1 hour',
    NOW() + INTERVAL '1 week',
    100,
    1000000,
    'upcoming'
  ),
  (
    'Weekend Trading Sprint',
    'Quick-paced weekend trading competition. Make the most profits in 48 hours!',
    NOW() + INTERVAL '2 days',
    NOW() + INTERVAL '4 days',
    50,
    1000000,
    'upcoming'
  ),
  (
    'Beginner''s Trading Event',
    'Perfect for new traders! Learn the basics of trading in a risk-free environment with guided tutorials.',
    NOW() + INTERVAL '3 days',
    NOW() + INTERVAL '10 days',
    200,
    1000000,
    'upcoming'
  ),
  (
    'Pro Trader Challenge',
    'Advanced trading competition for experienced traders. Higher stakes, bigger rewards!',
    NOW() + INTERVAL '5 days',
    NOW() + INTERVAL '12 days',
    75,
    1000000,
    'upcoming'
  );
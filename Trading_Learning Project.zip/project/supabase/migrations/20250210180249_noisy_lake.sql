/*
  # Add Themed Trading Events

  1. New Events
    - Adds 10 new themed trading events with different focuses:
      - DeFi Innovation Challenge
      - Layer 1 Battle Royale
      - Metaverse Masters
      - Scaling Solutions Sprint
      - NFT & Gaming Showdown
      - Web3 Infrastructure Cup
      - Green Crypto Challenge
      - Privacy Coins Contest
      - DeFi 2.0 Tournament
      - Cross-Chain Champions
*/

-- First add the theme_id column to trading_events table
ALTER TABLE trading_events ADD COLUMN IF NOT EXISTS theme_id text;

-- Then insert the new events
INSERT INTO trading_events (
  title,
  description,
  start_time,
  end_time,
  max_participants,
  initial_balance,
  status,
  theme_id
) VALUES
  (
    'DeFi Innovation Challenge',
    'Trade the most innovative DeFi tokens and compete for the top spot. Master yield farming, lending, and DEX tokens!',
    NOW() + INTERVAL '1 day',
    NOW() + INTERVAL '8 days',
    200,
    1000000,
    'upcoming',
    'defi-trading'
  ),
  (
    'Layer 1 Battle Royale',
    'Which blockchain will reign supreme? Trade major Layer 1 tokens and predict the future of blockchain infrastructure.',
    NOW() + INTERVAL '2 days',
    NOW() + INTERVAL '9 days',
    150,
    1000000,
    'upcoming',
    'layer1-battle'
  ),
  (
    'Metaverse Masters',
    'Enter the virtual world of trading! Compete with metaverse and gaming tokens in this exciting challenge.',
    NOW() + INTERVAL '3 days',
    NOW() + INTERVAL '10 days',
    175,
    1000000,
    'upcoming',
    'metaverse-gaming'
  ),
  (
    'Scaling Solutions Sprint',
    'Speed and scalability are the future. Trade Layer 2 and scaling solution tokens in this fast-paced event.',
    NOW() + INTERVAL '4 days',
    NOW() + INTERVAL '11 days',
    125,
    1000000,
    'upcoming',
    'scaling-solutions'
  ),
  (
    'NFT & Gaming Showdown',
    'The future of gaming and digital collectibles! Trade top gaming and NFT platform tokens.',
    NOW() + INTERVAL '5 days',
    NOW() + INTERVAL '12 days',
    200,
    1000000,
    'upcoming',
    'metaverse-gaming'
  ),
  (
    'Web3 Infrastructure Cup',
    'Build the future of the decentralized web. Trade tokens powering Web3 infrastructure.',
    NOW() + INTERVAL '6 days',
    NOW() + INTERVAL '13 days',
    150,
    1000000,
    'upcoming',
    'defi-trading'
  ),
  (
    'Green Crypto Challenge',
    'Focus on environmentally conscious blockchains and sustainable crypto projects.',
    NOW() + INTERVAL '7 days',
    NOW() + INTERVAL '14 days',
    175,
    1000000,
    'upcoming',
    'layer1-battle'
  ),
  (
    'Privacy Coins Contest',
    'Master the art of trading privacy-focused cryptocurrencies in this specialized event.',
    NOW() + INTERVAL '8 days',
    NOW() + INTERVAL '15 days',
    100,
    1000000,
    'upcoming',
    'layer1-battle'
  ),
  (
    'DeFi 2.0 Tournament',
    'Experience the next generation of DeFi. Trade innovative DeFi 2.0 tokens and protocols.',
    NOW() + INTERVAL '9 days',
    NOW() + INTERVAL '16 days',
    200,
    1000000,
    'upcoming',
    'defi-trading'
  ),
  (
    'Cross-Chain Champions',
    'Bridge the gap between blockchains. Trade cross-chain and interoperability focused tokens.',
    NOW() + INTERVAL '10 days',
    NOW() + INTERVAL '17 days',
    150,
    1000000,
    'upcoming',
    'scaling-solutions'
  );
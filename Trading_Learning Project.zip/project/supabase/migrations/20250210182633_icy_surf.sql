/*
  # Update Trading Events

  1. Changes
    - Update all existing events to start from today
    - Set all events to 'active' status
    - Adjust end times to be 7 days from start
    - Stagger event start times using row numbers instead of UUIDs

  2. Notes
    - Uses row_number() to safely stagger event times
    - Maintains 7-day duration for all events
*/

WITH numbered_events AS (
  SELECT 
    id,
    ROW_NUMBER() OVER (ORDER BY start_time) as row_num
  FROM trading_events
)
UPDATE trading_events
SET 
  start_time = NOW() + (SELECT row_num * INTERVAL '1 hour' FROM numbered_events WHERE numbered_events.id = trading_events.id),
  end_time = NOW() + INTERVAL '7 days' + (SELECT row_num * INTERVAL '1 hour' FROM numbered_events WHERE numbered_events.id = trading_events.id),
  status = 'active';
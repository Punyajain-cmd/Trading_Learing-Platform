/*
  # Create storage buckets for events and avatars

  1. New Storage Buckets
    - `events`: For storing event-related files and images
    - `avatars`: For storing user profile pictures
    
  2. Security
    - Enable public access for event images
    - Restrict avatar access to authenticated users
*/

-- Create storage bucket for events
INSERT INTO storage.buckets (id, name, public)
VALUES ('events', 'events', true);

-- Create storage bucket for avatars
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true);

-- Set up security policies for events bucket
CREATE POLICY "Public Access"
ON storage.objects FOR SELECT
USING (bucket_id = 'events');

-- Set up security policies for avatars bucket
CREATE POLICY "Avatar access for authenticated users only"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'avatars');

CREATE POLICY "Users can upload their own avatar"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'avatars' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can update their own avatar"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'avatars' AND
  (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'avatars' AND
  (storage.foldername(name))[1] = auth.uid()::text
);
/*
  # Add price alerts table

  1. New Tables
    - `price_alerts`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `crypto_symbol` (text)
      - `condition` (text, either 'above' or 'below')
      - `target_price` (numeric)
      - `status` (text)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `price_alerts` table
    - Add policies for CRUD operations
*/

-- Create price alerts table
CREATE TABLE public.price_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  crypto_symbol text NOT NULL,
  condition text NOT NULL CHECK (condition IN ('above', 'below')),
  target_price numeric NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'triggered', 'disabled')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE price_alerts ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own alerts"
  ON price_alerts
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create alerts"
  ON price_alerts
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their alerts"
  ON price_alerts
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their alerts"
  ON price_alerts
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes
CREATE INDEX price_alerts_user_id_idx ON price_alerts(user_id);
CREATE INDEX price_alerts_symbol_idx ON price_alerts(crypto_symbol);
/*
  # Update user profile fields

  1. New Columns
    - `real_name` (text) - User's real name
    - `date_of_birth` (date) - User's date of birth

  2. Security
    - Maintain existing RLS policies
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'real_name'
  ) THEN
    ALTER TABLE users ADD COLUMN real_name text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'date_of_birth'
  ) THEN
    ALTER TABLE users ADD COLUMN date_of_birth date;
  END IF;
END $$;
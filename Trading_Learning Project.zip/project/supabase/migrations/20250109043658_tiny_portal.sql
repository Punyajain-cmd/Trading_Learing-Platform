/*
  # Add user profile fields

  1. Changes
    - Add new columns to users table:
      - bio (text)
      - avatar_url (text)
      - trading_style (text)
      - experience_level (text)
      - favorite_markets (text)

  2. Security
    - Maintain existing RLS policies
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'bio'
  ) THEN
    ALTER TABLE users ADD COLUMN bio text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'avatar_url'
  ) THEN
    ALTER TABLE users ADD COLUMN avatar_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'trading_style'
  ) THEN
    ALTER TABLE users ADD COLUMN trading_style text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'experience_level'
  ) THEN
    ALTER TABLE users ADD COLUMN experience_level text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'favorite_markets'
  ) THEN
    ALTER TABLE users ADD COLUMN favorite_markets text;
  END IF;
END $$;
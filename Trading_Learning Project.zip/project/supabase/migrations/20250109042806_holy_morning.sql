/*
  # Initial Schema Setup for Trading Platform

  1. New Tables
    - users (extends auth.users)
      - id (uuid, primary key)
      - username (text)
      - game_money (numeric)
      - created_at (timestamp)
    
    - trading_events
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - start_time (timestamp)
      - end_time (timestamp)
      - max_participants (integer)
      - initial_balance (numeric)
      - status (text)
      - created_at (timestamp)
    
    - event_participants
      - id (uuid, primary key)
      - event_id (uuid, foreign key)
      - user_id (uuid, foreign key)
      - current_balance (numeric)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Users table extending auth.users
CREATE TABLE public.users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  username text UNIQUE NOT NULL,
  game_money numeric DEFAULT 10000,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Trading Events table
CREATE TABLE public.trading_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  max_participants integer NOT NULL,
  initial_balance numeric NOT NULL,
  status text NOT NULL DEFAULT 'upcoming',
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('upcoming', 'active', 'completed'))
);

ALTER TABLE trading_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read trading events"
  ON trading_events
  FOR SELECT
  TO authenticated
  USING (true);

-- Event Participants table
CREATE TABLE public.event_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES trading_events(id),
  user_id uuid REFERENCES users(id),
  current_balance numeric NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(event_id, user_id)
);

ALTER TABLE event_participants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own participations"
  ON event_participants
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own participations"
  ON event_participants
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);
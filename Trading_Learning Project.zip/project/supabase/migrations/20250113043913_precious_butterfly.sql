/*
  # Add banner URL to users table

  1. Changes
    - Add banner_url column to users table
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'banner_url'
  ) THEN
    ALTER TABLE users ADD COLUMN banner_url text;
  END IF;
END $$;
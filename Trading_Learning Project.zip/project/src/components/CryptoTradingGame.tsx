import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { supabase } from '../lib/supabase';
import { ArrowUpCircle, ArrowDownCircle, DollarSign, Clock, TrendingUp, TrendingDown, BarChart2, History } from 'lucide-react';
import { format } from 'date-fns';
import { initializePriceWebSocket, cleanupWebSocket, priceUpdates } from '../lib/api';

interface CryptoPrice {
  timestamp: number;
  price: number;
  volume?: number;
}

interface Position {
  crypto: string;
  amount: number;
  entryPrice: number;
  timestamp: number;
  type: 'buy' | 'sell';
  profitLoss?: number;
}

const CRYPTO_LIST = [
  { symbol: 'BTC', name: 'Bitcoin' },
  { symbol: 'ETH', name: 'Ethereum' },
  { symbol: 'BNB', name: 'Binance Coin' },
  { symbol: 'SOL', name: 'Solana' },
  { symbol: 'ADA', name: 'Cardano' }
];

export default function CryptoTradingGame({ eventId, userId }: { eventId: string; userId: string }) {
  const [balance, setBalance] = useState(1000000); // ₹10 Lakh
  const [selectedCrypto, setSelectedCrypto] = useState(CRYPTO_LIST[0]);
  const [priceHistory, setPriceHistory] = useState<CryptoPrice[]>([]);
  const [currentPrice, setCurrentPrice] = useState(0);
  const [tradeHistory, setTradeHistory] = useState<Position[]>([]);
  const [positions, setPositions] = useState<Position[]>([]);
  const [tradeAmount, setTradeAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  // Load initial balance and positions
  useEffect(() => {
    initializePriceWebSocket([selectedCrypto.symbol]);

    const loadUserState = async () => {
      try {
        // Get user's current balance from event participation
        const { data: participantData, error: participantError } = await supabase
          .from('event_participants')
          .select('current_balance')
          .eq('event_id', eventId)
          .eq('user_id', userId)
          .single();

        if (participantError) throw participantError;
        if (participantData) {
          setBalance(participantData.current_balance);
        }

        // Get user's positions for this event
        const { data: positionsData, error: positionsError } = await supabase
          .from('trading_positions')
          .select('*')
          .eq('event_id', eventId)
          .eq('user_id', userId);

        if (positionsError) throw positionsError;
        if (positionsData) {
          setPositions(positionsData.map(pos => ({
            crypto: pos.crypto_symbol,
            amount: pos.amount,
            entryPrice: pos.entry_price
          })));
        }
      } catch (error) {
        console.error('Error loading user state:', error);
        setMessage('Error loading your trading data. Please try refreshing the page.');
      }
    };

    loadUserState();

    return () => {
      cleanupWebSocket();
    };
  }, [eventId, userId]);

  useEffect(() => {
    initializePriceHistory();
    const interval = setInterval(updatePrice, 3000);
    return () => clearInterval(interval);
  }, [selectedCrypto]);

  useEffect(() => {
    const subscription = priceUpdates.subscribe(update => {
      if (update.symbol === selectedCrypto.symbol) {
        // Update current price immediately
        setCurrentPrice(update.price);

        // Add to price history
        const newPrice = {
          timestamp: update.timestamp,
          price: update.price
        };

        setPriceHistory(prev => {
          // Keep only last 50 data points for smoother chart
          const newHistory = [...prev.slice(-49), newPrice];
          if (newHistory.length > 50) {
            return newHistory.slice(-50);
          }
          return newHistory;
        });

        // Update positions with new price
        updatePositions(update.price);
      }
    });

    return () => subscription.unsubscribe();
  }, [selectedCrypto]);

  const initializePriceHistory = () => {
    // Generate initial price history
    const basePrice = getBasePrice(selectedCrypto.symbol);
    const history: CryptoPrice[] = [];
    const now = Date.now();
    
    for (let i = 0; i < 20; i++) {
      history.push({
        timestamp: now - (19 - i) * 3000,
        price: basePrice * (1 + (Math.random() - 0.5) * 0.1)
      });
    }
    
    setPriceHistory(history);
    setCurrentPrice(history[history.length - 1].price);
  };

  const getBasePrice = (symbol: string) => {
    switch (symbol) {
      case 'BTC': return 4000000;
      case 'ETH': return 250000;
      case 'BNB': return 35000;
      case 'SOL': return 8000;
      case 'ADA': return 50;
      default: return 1000;
    }
  };

  const updatePrice = () => {
    if (!priceHistory.length) return;
    
    const lastPrice = priceHistory[priceHistory.length - 1].price;
    const change = (Math.random() - 0.5) * 0.02; // 2% max change
    const newPrice = lastPrice * (1 + change);
    
    const newHistory = [
      ...priceHistory.slice(1),
      { timestamp: Date.now(), price: newPrice }
    ];
    
    setPriceHistory(newHistory);
    setCurrentPrice(newPrice);
    updatePositions(newPrice);
  };

  const updatePositions = async (newPrice: number) => {
    if (!positions.length) return;
    
    const updatedPositions = positions.map(pos => {
      const currentPriceForPosition = pos.crypto === selectedCrypto.symbol ? newPrice : currentPrice;
      return {
        ...pos,
        currentValue: pos.amount * currentPriceForPosition,
        profitLoss: (currentPriceForPosition - pos.entryPrice) * pos.amount
      };
    });

    const totalValue = balance + updatedPositions.reduce((sum, pos) => 
      sum + (pos.amount * (pos.crypto === selectedCrypto.symbol ? newPrice : currentPrice)), 0);

    try {
      // Update event balance
      await supabase
        .from('event_participants')
        .update({ current_balance: totalValue })
        .eq('event_id', eventId)
        .eq('user_id', userId);

      // Update positions in database
      await Promise.all(positions.map(async (position) => {
        const { error } = await supabase
          .from('trading_positions')
          .upsert({
            event_id: eventId,
            user_id: userId,
            crypto_symbol: position.crypto,
            amount: position.amount,
            entry_price: position.entryPrice
          }, {
            onConflict: 'event_id,user_id,crypto_symbol'
          });

        if (error) throw error;
      }));

      // Clean up closed positions
      const { error: deleteError } = await supabase
        .from('trading_positions')
        .delete()
        .eq('event_id', eventId)
        .eq('user_id', userId)
        .not('crypto_symbol', 'in', `(${positions.map(p => `'${p.crypto}'`).join(',')})`);

      if (deleteError) throw deleteError;

    } catch (error) {
      console.error('Error updating balance:', error);
    }
  };

  const handleTrade = async (isBuy: boolean) => {
    setLoading(true);
    setMessage('');
    const amount = parseFloat(tradeAmount);

    if (!amount || isNaN(amount) || amount <= 0) {
      setMessage('Please enter an amount');
      setLoading(false);
      return;
    }

    try {
      const cryptoAmount = amount / currentPrice;

      // Start transaction by updating balance first
      const newBalance = isBuy ? balance - amount : balance + amount;
      const { error: balanceError } = await supabase
        .from('event_participants')
        .update({ current_balance: newBalance })
        .eq('event_id', eventId)
        .eq('user_id', userId);

      if (balanceError) throw balanceError;

      // Check if amount exceeds available balance
      if (isBuy && amount > balance) {
        setMessage('Insufficient funds');
        setLoading(false);
        return;
      }

      // For selling, check if user has enough crypto
      if (!isBuy) {
        const position = positions.find(p => p.crypto === selectedCrypto.symbol);
        if (!position || position.amount < cryptoAmount) {
          setMessage(`Insufficient ${selectedCrypto.symbol} balance`);
          setLoading(false);
          return;
        }
      }

      if (isBuy) {
        // For buying, insert new position or update existing
        const existingPosition = positions.find(p => p.crypto === selectedCrypto.symbol);
        if (existingPosition) {
          const newAmount = existingPosition.amount + cryptoAmount;
          const newEntryPrice = (existingPosition.amount * existingPosition.entryPrice + cryptoAmount * currentPrice) / newAmount;
          
          const { error: updateError } = await supabase
            .from('trading_positions')
            .update({
              amount: newAmount,
              entry_price: newEntryPrice
            })
            .eq('event_id', eventId)
            .eq('user_id', userId)
            .eq('crypto_symbol', selectedCrypto.symbol);

          if (updateError) throw updateError;
          
          setPositions(prev => prev.map(p => 
            p.crypto === selectedCrypto.symbol ? { ...p, amount: newAmount, entryPrice: newEntryPrice } : p
          ));
        } else {
          const { error: insertError } = await supabase
            .from('trading_positions')
            .insert({
              event_id: eventId,
              user_id: userId,
              crypto_symbol: selectedCrypto.symbol,
              amount: cryptoAmount,
              entry_price: currentPrice
            });

          if (insertError) throw insertError;
          
          setPositions(prev => [...prev, {
            crypto: selectedCrypto.symbol,
            amount: cryptoAmount,
            entryPrice: currentPrice
          }]);
        }
        
        setMessage(`Bought ${cryptoAmount.toFixed(8)} ${selectedCrypto.symbol} for ₹${amount.toFixed(2)}`);
      } else {
        const position = positions.find(p => p.crypto === selectedCrypto.symbol);
        if (!position || position.amount < cryptoAmount) {
          setMessage('Insufficient crypto balance');
          setLoading(false);
          return;
        }

        const newAmount = position.amount - cryptoAmount;
        const profitLoss = (currentPrice - position.entryPrice) * cryptoAmount;
        
        // For selling, update position with new amount or delete if zero
        if (newAmount > 0) {
          const { error: updateError } = await supabase
            .from('trading_positions')
            .update({ amount: newAmount })
            .eq('event_id', eventId)
            .eq('user_id', userId)
            .eq('crypto_symbol', selectedCrypto.symbol);

          if (updateError) throw updateError;

          setPositions(prev => prev.map(p => 
            p.crypto === selectedCrypto.symbol ? { ...p, amount: newAmount } : p
          ));
        } else {
          const { error: deleteError } = await supabase
            .from('trading_positions')
            .delete()
            .eq('event_id', eventId)
            .eq('user_id', userId)
            .eq('crypto_symbol', selectedCrypto.symbol);

          if (deleteError) throw deleteError;

          setPositions(positions.filter(p => p.crypto !== selectedCrypto.symbol));
        }
        
        const profitLossMsg = profitLoss >= 0 ? 
          ` with profit ₹${profitLoss.toFixed(2)}` : 
          ` with loss ₹${Math.abs(profitLoss).toFixed(2)}`;
        setMessage(`Sold ${cryptoAmount.toFixed(8)} ${selectedCrypto.symbol}${profitLossMsg}`);
      }

      // Update local balance state after successful database operations
      setBalance(newBalance);

      setTradeAmount('');
      setTradeHistory(prev => [...prev, {
        crypto: selectedCrypto.symbol,
        amount: cryptoAmount,
        entryPrice: currentPrice,
        timestamp: Date.now(),
        type: isBuy ? 'buy' : 'sell',
        profitLoss: isBuy ? 0 : profitLoss
      }]);

    } catch (error) {
      console.error('Trade error:', error);
      setMessage('Trade failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg space-y-8">
      {/* Price Chart */}
      <div className="mb-8 animate-fade-in">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">{selectedCrypto.name} Price Chart</h3>
          <select
            value={selectedCrypto.symbol}
            onChange={(e) => setSelectedCrypto(CRYPTO_LIST.find(c => c.symbol === e.target.value)!)}
            className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          >
            {CRYPTO_LIST.map(crypto => (
              <option key={crypto.symbol} value={crypto.symbol}>
                {crypto.name}
              </option>
            ))}
          </select>
        </div>
        
        <LineChart width={800} height={400} data={priceHistory.slice(-50)} className="bg-gray-50 rounded-lg p-4 animate-fade-in">
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="timestamp"
            tickFormatter={(timestamp) => format(timestamp, 'HH:mm:ss')}
          />
          <YAxis />
          <Tooltip
            labelFormatter={(timestamp) => format(timestamp, 'HH:mm:ss')}
            formatter={(value: number) => [`₹${value.toFixed(2)}`, 'Price']}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="price"
            stroke="#4f46e5"
            dot={false}
            animationDuration={300}
            isAnimationActive={true}
            name="Price"
          />
        </LineChart>
      </div>

      {/* Trading Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold mb-4">Trading</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Current Price
                <span className="text-xs text-gray-500 ml-2">
                  (Updates every 3 seconds)
                </span>
              </label>
              <div className="flex items-center mt-1">
                <Clock className="h-4 w-4 text-gray-400 mr-2" />
                <span className="text-sm text-gray-500">
                  Last updated: {format(new Date(), 'HH:mm:ss')}
                </span>
              </div>
              <div className="mt-1 text-2xl font-bold text-indigo-600 transition-all duration-300">
                ₹{currentPrice.toFixed(2)}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Amount (₹)
                <span className="text-xs text-gray-500 ml-2">
                  Available: ₹{balance.toFixed(2)}
                </span>
              </label>
              <div className="mt-1">
                <input
                  type="number"
                  value={tradeAmount}
                  onChange={(e) => {
                    const value = e.target.value;
                    if (!value || parseFloat(value) <= balance) {
                      setTradeAmount(value);
                    }
                  }}
                  className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md transition-all duration-300"
                  placeholder="Enter amount in ₹"
                />
              </div>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => handleTrade(true)}
                disabled={loading || !tradeAmount}
                className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                <ArrowUpCircle className="h-5 w-5 mr-2" />
                Buy
              </button>
              <button
                onClick={() => handleTrade(false)}
                disabled={loading || !tradeAmount}
                className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                <ArrowDownCircle className="h-5 w-5 mr-2" />
                Sell
              </button>
            </div>

            {message && (
              <div className="mt-2 p-2 rounded-md bg-gray-50 text-sm text-gray-600 animate-fade-in transition-all duration-300">
                {message}
              </div>
            )}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-4">Portfolio</h3>
          <div className="space-y-6 animate-fade-in">
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="text-sm text-gray-500">Available Balance</div>
              <div className="text-2xl font-bold text-indigo-600">
                ₹{balance.toFixed(2)}
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 transition-all duration-300">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Positions</h4>
              <div className="space-y-2">
                {positions.map((position, index) => (
                  <div key={index} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">{position.crypto}</div>
                        <div className="text-sm text-gray-500">
                          Amount: {position.amount}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">
                          Entry: ₹{position.entryPrice.toFixed(2)}
                        </div>
                        <div className={`text-sm flex items-center transition-colors duration-300 ${
                          position.profitLoss && position.profitLoss >= 0
                            ? 'text-green-600'
                            : 'text-red-600'
                        }`}>
                          {position.profitLoss && position.profitLoss >= 0 ? (
                            <TrendingUp className="h-4 w-4 mr-1" />
                          ) : <TrendingDown className="h-4 w-4 mr-1" />}
                          <span>
                            Current: ₹{
                              position.crypto === selectedCrypto.symbol
                                ? currentPrice.toFixed(2)
                                : position.entryPrice.toFixed(2)
                            } ({position.profitLoss >= 0 ? '+' : ''}
                            {((position.profitLoss || 0) / (position.amount * position.entryPrice) * 100).toFixed(2)}%)
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {positions.length === 0 && (
                  <div className="text-sm text-gray-500">
                    No open positions
                  </div>
                )}
              </div>
            </div>

            {/* Trade History */}
            <div className="bg-gray-50 rounded-lg p-4 transition-all duration-300">
              <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                <History className="h-4 w-4 mr-2" />
                Trade History
              </h4>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {tradeHistory.map((trade, index) => (
                  <div key={index} className="bg-white p-3 rounded-lg shadow-sm">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium flex items-center">
                          {trade.type === 'buy' ? (
                            <ArrowUpCircle className="h-4 w-4 mr-1 text-green-500" />
                          ) : (
                            <ArrowDownCircle className="h-4 w-4 mr-1 text-red-500" />
                          )}
                          {trade.type === 'buy' ? 'Bought' : 'Sold'} {trade.crypto}
                        </div>
                        <div className="text-sm text-gray-500">
                          Amount: {trade.amount}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">
                          ₹{trade.entryPrice.toFixed(2)}
                        </div>
                        {trade.type === 'sell' && (
                          <div className={`text-xs ${trade.profitLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {trade.profitLoss >= 0 ? '+' : '-'}
                            ₹{Math.abs(trade.profitLoss || 0).toFixed(2)}
                          </div>
                        )}
                        <div className="text-sm text-gray-500">
                          {format(trade.timestamp, 'HH:mm:ss')}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { getCryptoPrices, CryptoPrice } from '../lib/api';
import LivePriceChart from './LivePriceChart';
import CryptoTradingGame from './CryptoTradingGame';
import { TrendingUp, TrendingDown, DollarSign, BarChart2, ChevronRight, Trophy, Users, Lock, Crown } from 'lucide-react';

interface EventTradingInterfaceProps {
  eventId: string;
  userId: string;
  eventTheme: {
    name: string;
    description: string;
    allowedCoins: string[];
  };
}

export default function EventTradingInterface({ eventId, userId, eventTheme }: EventTradingInterfaceProps) {
  const [activeTab, setActiveTab] = useState('trading');
  const [coins, setCoins] = useState<CryptoPrice[]>([]);
  const [selectedCoin, setSelectedCoin] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [portfolioValue, setPortfolioValue] = useState(1000000); // ₹10 Lakh initial
  const [profitLoss, setProfitLoss] = useState(0);
  const [leaderboard, setLeaderboard] = useState([
    { rank: 1, name: 'Trader Alpha', profit: 2500000, roi: 25 },
    { rank: 2, name: 'Crypto Master', profit: 2000000, roi: 20 },
    { rank: 3, name: 'Trading Pro', profit: 1500000, roi: 15 },
    { rank: 4, name: 'Market Guru', profit: 1000000, roi: 10 },
    { rank: 5, name: 'DeFi Expert', profit: 500000, roi: 5 }
  ]);
  const [popularCoins, setPopularCoins] = useState([
    { symbol: 'BTC', name: 'Bitcoin', investors: 150, volume: 5000000 },
    { symbol: 'ETH', name: 'Ethereum', investors: 120, volume: 3000000 },
    { symbol: 'SOL', name: 'Solana', investors: 90, volume: 2000000 },
    { symbol: 'BNB', name: 'Binance Coin', investors: 80, volume: 1500000 },
    { symbol: 'ADA', name: 'Cardano', investors: 70, volume: 1000000 }
  ]);
  const [winners, setWinners] = useState([
    { rank: 1, name: 'Last Week Champion', prize: '₹500,000', roi: 35 },
    { rank: 2, name: 'Silver Trader', prize: '₹300,000', roi: 28 },
    { rank: 3, name: 'Bronze Expert', prize: '₹200,000', roi: 22 }
  ]);

  useEffect(() => {
    const fetchEventCoins = async () => {
      try {
        const allCoins = await getCryptoPrices();
        const eventCoins = allCoins.filter(coin => 
          eventTheme.allowedCoins.includes(coin.symbol.toLowerCase())
        );
        setCoins(eventCoins);
      } catch (error) {
        console.error('Error fetching event coins:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchEventCoins();
  }, [eventTheme.allowedCoins]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Navigation Tabs */}
      <div className="mb-8 border-b border-gray-200">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          {[
            { id: 'trading', name: 'Trading', icon: <BarChart2 className="h-5 w-5" /> },
            { id: 'leaderboard', name: 'Leaderboard', icon: <Trophy className="h-5 w-5" /> },
            { id: 'popular', name: 'Popular Coins', icon: <Users className="h-5 w-5" /> },
            { id: 'winners', name: 'Winners', icon: <Crown className="h-5 w-5" /> }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`${
                activeTab === tab.id
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } flex items-center px-1 py-4 border-b-2 font-medium text-sm`}
            >
              {tab.icon}
              <span className="ml-2">{tab.name}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Trading Interface */}
      {activeTab === 'trading' && (
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg p-6 text-white">
          <h2 className="text-2xl font-bold mb-2">{eventTheme.name}</h2>
          <p className="text-indigo-100">{eventTheme.description}</p>
        </div>
      )}

      {/* Leaderboard */}
      {activeTab === 'leaderboard' && (
        <div className="bg-white rounded-lg shadow">
          <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <Trophy className="h-5 w-5 text-yellow-500 mr-2" />
              Current Event Leaderboard
            </h3>
          </div>
          <div className="overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rank</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trader</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Profit</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ROI</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {leaderboard.map((trader) => (
                  <tr key={trader.rank} className={trader.rank <= 3 ? 'bg-yellow-50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">#{trader.rank}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{trader.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">₹{trader.profit.toLocaleString()}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        +{trader.roi}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Popular Coins */}
      {activeTab === 'popular' && (
        <div className="bg-white rounded-lg shadow">
          <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <Users className="h-5 w-5 text-indigo-500 mr-2" />
              Most Popular Coins
            </h3>
          </div>
          <div className="overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Coin</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Investors</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trading Volume</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {popularCoins.map((coin) => (
                  <tr key={coin.symbol}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="text-sm font-medium text-gray-900">{coin.name}</div>
                        <div className="ml-2 text-sm text-gray-500">({coin.symbol})</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{coin.investors}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">₹{coin.volume.toLocaleString()}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Winners List (Locked) */}
      {activeTab === 'winners' && (
        <div className="relative">
          <div className="bg-white rounded-lg shadow overflow-hidden filter blur-sm pointer-events-none">
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 flex items-center">
                <Crown className="h-5 w-5 text-yellow-500 mr-2" />
                Previous Winners
              </h3>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
                {winners.map((winner) => (
                  <div key={winner.rank} className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <Crown className={`h-8 w-8 ${
                        winner.rank === 1 ? 'text-yellow-500' :
                        winner.rank === 2 ? 'text-gray-400' :
                        'text-yellow-700'
                      }`} />
                      <span className="text-2xl font-bold">#{winner.rank}</span>
                    </div>
                    <h4 className="text-lg font-semibold mb-2">{winner.name}</h4>
                    <div className="text-sm text-gray-600">Prize: {winner.prize}</div>
                    <div className="mt-2">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        ROI: +{winner.roi}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          {/* Lock Overlay */}
          <div className="absolute inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50 rounded-lg">
            <div className="text-center text-white">
              <Lock className="h-16 w-16 mx-auto mb-4 animate-bounce" />
              <h3 className="text-xl font-bold mb-2">Winners List Locked</h3>
              <p className="text-sm">Complete at least one event to unlock the winners list</p>
            </div>
          </div>
        </div>
      )}

      {/* Main Trading Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        {/* Coin List */}
        <div className="lg:col-span-1 bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Available Coins</h3>
          </div>
          <div className="divide-y divide-gray-200 max-h-[600px] overflow-y-auto">
            {coins.map((coin) => (
              <div
                key={coin.id}
                className={`p-4 hover:bg-gray-50 cursor-pointer transition-colors duration-150 ${
                  selectedCoin === coin.symbol ? 'bg-indigo-50' : ''
                }`}
                onClick={() => setSelectedCoin(coin.symbol)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img
                      src={coin.image}
                      alt={coin.name}
                      className="w-8 h-8 rounded-full"
                    />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-900">{coin.name}</p>
                      <p className="text-xs text-gray-500">{coin.symbol.toUpperCase()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">
                      ₹{coin.current_price.toLocaleString()}
                    </p>
                    <p className={`text-xs ${
                      coin.price_change_percentage_24h >= 0 
                        ? 'text-green-600' 
                        : 'text-red-600'
                    }`}>
                      {coin.price_change_percentage_24h >= 0 ? '+' : ''}
                      {coin.price_change_percentage_24h.toFixed(2)}%
                    </p>
                  </div>
                </div>
                {selectedCoin === coin.symbol && (
                  <div className="mt-4 h-32">
                    <LivePriceChart
                      symbol={coin.symbol}
                      height="100%"
                      showAxes={false}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Trading Interface */}
        <div className="lg:col-span-2">
          {selectedCoin ? (
            <CryptoTradingGame eventId={eventId} userId={userId} />
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <BarChart2 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Select a coin to start trading
              </h3>
              <p className="text-gray-500">
                Click on any coin from the list to view detailed information and start trading
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
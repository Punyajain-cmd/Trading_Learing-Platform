import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { LogOut, User, Menu, X, Info, HelpCircle, Coins, BarChart2, Briefcase, Star, Newspaper, Trophy } from 'lucide-react';

export default function Navbar() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  const isActivePath = (path: string) => {
    return location.pathname === path;
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="bg-white shadow">
      {/* Container using full width */}
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Left Section: Logo + Main Nav Links */}
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              {/* MODIFICATION: Further increased text size for BitMore logo */}
              <Link to="/" className="text-3xl font-bold text-indigo-600"> {/* Was: text-2xl */}
                BitMore
              </Link>
            </div>
            {/* Desktop Nav Links */}
            {/* MODIFICATION: Further increased left margin for spacing */}
            <div className="hidden sm:ml-12 sm:flex sm:space-x-8"> {/* Was: sm:ml-8 */}
              {user ? (
                <>
                  {/* User links */}
                  <Link to="/crypto" className={`${ isActivePath('/crypto') ? 'border-indigo-500 text-gray-900' : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700' } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-16`}> <Coins className="h-4 w-4 mr-2" /> Cryptocurrencies </Link>
                  <Link to="/categories" className={`${ isActivePath('/categories') ? 'border-indigo-500 text-gray-900' : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700' } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-16`}> <BarChart2 className="h-4 w-4 mr-2" /> Categories </Link>
                  <Link to="/portfolio" className={`${ isActivePath('/portfolio') ? 'border-indigo-500 text-gray-900' : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700' } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-16`}> <Briefcase className="h-4 w-4 mr-2" /> Portfolio </Link>
                  <Link to="/watchlist" className={`${ isActivePath('/watchlist') ? 'border-indigo-500 text-gray-900' : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700' } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-16`}> <Star className="h-4 w-4 mr-2" /> Watchlist </Link>
                  <Link to="/news" className={`${ isActivePath('/news') ? 'border-indigo-500 text-gray-900' : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700' } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-16`}> <Newspaper className="h-4 w-4 mr-2" /> News </Link>
                  <Link to="/live-games" className={`${ isActivePath('/live-games') ? 'border-indigo-500 text-gray-900' : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700' } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-16`}> <Trophy className="h-4 w-4 mr-2" /> Live Trading </Link>
                  <Link to="/my-events" className={`${ isActivePath('/my-events') ? 'border-indigo-500 text-gray-900' : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700' } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-16`}> <Trophy className="h-4 w-4 mr-2" /> My Events </Link>
                </>
              ) : (
                <>
                  {/* Non-user links */}
                  <Link to="/about" className={`${ isActivePath('/about') ? 'border-indigo-500 text-gray-900' : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700' } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-16`}> <Info className="h-4 w-4 mr-2" /> About </Link>
                  <Link to="/how-it-works" className={`${ isActivePath('/how-it-works') ? 'border-indigo-500 text-gray-900' : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700' } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-16`}> <HelpCircle className="h-4 w-4 mr-2" /> How It Works </Link>
                </>
              )}
            </div>
          </div>

          {/* Right Section: User/Auth Buttons (Desktop) */}
          <div className="hidden sm:ml-6 sm:flex sm:items-center space-x-4">
            {user ? (
              <>
                {/* Dashboard Button (Gradient style) */}
                <Link
                  to="/dashboard"
                  className="group relative inline-flex items-center px-6 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 transition-all duration-200 shadow-sm hover:shadow-md min-w-[140px] justify-center"
                >
                  <User className="h-4 w-4 mr-2" />
                  Dashboard
                </Link>
                {/* Sign Out Button (Light style) */}
                <button
                  onClick={handleSignOut}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-600 bg-indigo-50 hover:bg-indigo-100"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </button>
              </>
            ) : (
              // Sign In Button
              <Link
                to="/auth"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
              >
                Sign In
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="sm:hidden flex items-center">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
            >
              <span className="sr-only">Open main menu</span>
              {isMobileMenuOpen ? (
                <X className="block h-6 w-6" />
              ) : (
                <Menu className="block h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu (remains unchanged) */}
      {isMobileMenuOpen && (
        <div className="sm:hidden">
           <div className="pt-2 pb-3 space-y-1">
            {user ? (
              <>
                {/* Mobile User links */}
                <Link to="/crypto" onClick={closeMobileMenu} className={`${ isActivePath('/crypto') ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700' } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}> <Coins className="inline-block h-4 w-4 mr-2" /> Cryptocurrencies </Link>
                <Link to="/categories" onClick={closeMobileMenu} className={`${ isActivePath('/categories') ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700' } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}> <BarChart2 className="inline-block h-4 w-4 mr-2" /> Categories </Link>
                <Link to="/portfolio" onClick={closeMobileMenu} className={`${ isActivePath('/portfolio') ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700' } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}> <Briefcase className="inline-block h-4 w-4 mr-2" /> Portfolio </Link>
                <Link to="/watchlist" onClick={closeMobileMenu} className={`${ isActivePath('/watchlist') ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700' } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}> <Star className="inline-block h-4 w-4 mr-2" /> Watchlist </Link>
                <Link to="/news" onClick={closeMobileMenu} className={`${ isActivePath('/news') ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700' } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}> <Newspaper className="inline-block h-4 w-4 mr-2" /> News </Link>
                <Link to="/live-games" onClick={closeMobileMenu} className={`${ isActivePath('/live-games') ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700' } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}> <Trophy className="inline-block h-4 w-4 mr-2" /> Live Games </Link>
                <Link to="/my-events" onClick={closeMobileMenu} className={`${ isActivePath('/my-events') ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700' } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}> <Trophy className="inline-block h-4 w-4 mr-2" /> My Events </Link>
              </>
            ) : (
              <>
                {/* Mobile Non-user links */}
                <Link to="/about" onClick={closeMobileMenu} className={`${ isActivePath('/about') ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700' } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}> About </Link>
                <Link to="/how-it-works" onClick={closeMobileMenu} className={`${ isActivePath('/how-it-works') ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700' } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}> How It Works </Link>
              </>
            )}
          </div>
          <div className="pt-4 pb-3 border-t border-gray-200">
            {user ? (
              <div className="space-y-1">
                <Link to="/dashboard" onClick={closeMobileMenu} className="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"> <User className="inline-block h-4 w-4 mr-2" /> Dashboard </Link>
                <button onClick={() => { handleSignOut(); closeMobileMenu(); }} className="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"> <LogOut className="inline-block h-4 w-4 mr-2" /> Sign Out </button>
              </div>
            ) : (
              <div className="px-4">
                <Link to="/auth" onClick={closeMobileMenu} className="block text-center w-full px-4 py-2 text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"> Sign In </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
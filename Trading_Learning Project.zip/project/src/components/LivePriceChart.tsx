import React, { useEffect, useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { priceUpdates, getPriceHistory } from '../lib/api';
import { format } from 'date-fns';

interface LivePriceChartProps {
  symbol: string;
  color?: string;
  height?: number | string;
  showAxes?: boolean;
}

export default function LivePriceChart({ 
  symbol, 
  color = '#4f46e5',
  height = 200,
  showAxes = true 
}: LivePriceChartProps) {
  const [data, setData] = useState<{ timestamp: number; price: number; }[]>(() => {
    // Generate initial mock data while waiting for real data
    const mockData = [];
    const now = Date.now();
    const basePrice = getInitialPrice(symbol);
    
    for (let i = 0; i < 20; i++) {
      mockData.push({
        timestamp: now - (19 - i) * 1000,
        price: basePrice * (1 + (Math.random() - 0.5) * 0.02)
      });
    }
    
    // Merge with any existing history
    const history = getPriceHistory(symbol);
    return history.length > 0 ? history : mockData;
  });

  // Helper function to get realistic initial prices for different symbols
  function getInitialPrice(symbol: string): number {
    const prices: { [key: string]: number } = {
      'BTC': 42000,
      'ETH': 2300,
      'BNB': 310,
      'SOL': 100,
      'ADA': 0.5,
      'DOT': 6.7,
      'LINK': 14,
      'MATIC': 0.9,
      'AVAX': 34,
      'UNI': 5.6
    };
    return prices[symbol] || 100;
  }

  useEffect(() => {
    // Reset data with new mock data when symbol changes
    setData(() => {
      const mockData = [];
      const now = Date.now();
      const basePrice = getInitialPrice(symbol);
      
      for (let i = 0; i < 20; i++) {
        mockData.push({
          timestamp: now - (19 - i) * 1000,
          price: basePrice * (1 + (Math.random() - 0.5) * 0.02)
        });
      }
      
      const history = getPriceHistory(symbol);
      return history.length > 0 ? history : mockData;
    });

    const subscription = priceUpdates.subscribe(update => {
      if (update.symbol === symbol) {
        setData(prevData => {
          const newData = [...prevData, {
            timestamp: update.timestamp,
            price: update.price
          }];
          if (newData.length > 100) newData.shift();
          return newData;
        });
      }
    });

    return () => subscription.unsubscribe();
  }, [symbol]);

  const priceChange = data.length > 1 
    ? ((data[data.length - 1].price - data[0].price) / Math.abs(data[0].price)) * 100
    : 0;

  const chartColor = priceChange >= 0 ? '#10B981' : '#EF4444';

  return (
    <div className="w-full" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id={`gradient-${symbol}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={chartColor} stopOpacity={0.4}/>
              <stop offset="75%" stopColor={chartColor} stopOpacity={0.05}/>
            </linearGradient>
            <filter id="shadow" height="200%">
              <feGaussianBlur in="SourceAlpha" stdDeviation="3" result="blur" />
              <feOffset in="blur" dx="0" dy="4" result="offsetBlur"/>
              <feMerge>
                <feMergeNode in="offsetBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          {showAxes && (
            <>
              <XAxis
                dataKey="timestamp"
                tickFormatter={(timestamp) => format(timestamp, 'HH:mm:ss')}
                stroke="#6B7280"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                dy={10}
              />
              <YAxis
                domain={['auto', 'auto']}
                stroke="#6B7280"
                fontSize={11}
                tickFormatter={(value) => `$${value.toLocaleString()}`}
                tickLine={false}
                axisLine={false}
                dx={-10}
              />
            </>
          )}
          <CartesianGrid
            strokeDasharray="3 3"
            vertical={false}
            stroke="#E5E7EB"
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                return (
                  <div className="bg-white shadow-lg rounded-lg p-3 border border-gray-100">
                    <p className="text-xs text-gray-500 mb-1">
                      {format(payload[0].payload.timestamp, 'HH:mm:ss')}
                    </p>
                    <p className="text-base font-bold text-gray-900">
                      ${payload[0].value.toLocaleString()}
                    </p>
                    <p className={`text-xs ${priceChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(2)}%
                    </p>
                  </div>
                );
              }
              return null;
            }}
            cursor={{ stroke: chartColor, strokeWidth: 1, strokeDasharray: '5 5' }}
          />
          <Area
            type="monotone"
            dataKey="price"
            stroke={chartColor}
            strokeWidth={2}
            fill={`url(#gradient-${symbol})`}
            dot={false}
            activeDot={{
              r: 6,
              fill: 'white',
              stroke: chartColor,
              strokeWidth: 2,
              filter: 'url(#shadow)'
            }}
            animationDuration={300}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Check, Phone, Loader, ChevronDown } from 'lucide-react';

interface PhoneVerificationProps {
  userId: string;
  onVerified: () => void;
}

interface Country {
  name: string;
  code: string;
  dial_code: string;
  flag: string;
}

// List of countries with dial codes (showing a subset with India first)
const countries: Country[] = [
  {
    name: "India",
    code: "IN",
    dial_code: "+91",
    flag: "🇮🇳"
  },
  {
    name: "United States",
    code: "US",
    dial_code: "+1",
    flag: "🇺🇸"
  },
  {
    name: "United Kingdom",
    code: "GB",
    dial_code: "+44",
    flag: "🇬🇧"
  },
  {
    name: "Canada",
    code: "CA",
    dial_code: "+1",
    flag: "🇨🇦"
  },
  {
    name: "Australia",
    code: "AU",
    dial_code: "+61",
    flag: "🇦🇺"
  },
  {
    name: "Singapore",
    code: "SG",
    dial_code: "+65",
    flag: "🇸🇬"
  },
  {
    name: "United Arab Emirates",
    code: "AE",
    dial_code: "+971",
    flag: "🇦🇪"
  }
];

export default function PhoneVerification({ userId, onVerified }: PhoneVerificationProps) {
  const [selectedCountry, setSelectedCountry] = useState(countries[0]); // India by default
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [codeSent, setCodeSent] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendTimer > 0) {
      timer = setInterval(() => {
        setResendTimer(prev => prev - 1);
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [resendTimer]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const dropdown = document.getElementById('country-dropdown');
      if (dropdown && !dropdown.contains(event.target as Node)) {
        setShowCountryDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const sendVerificationCode = async () => {
    try {
      setLoading(true);
      setError('');

      const fullPhoneNumber = selectedCountry.dial_code + phoneNumber;
      
      // Validate phone number format (international format without the plus sign)
      const phoneRegex = /^\+[1-9]\d{1,14}$/;
      if (!phoneRegex.test(fullPhoneNumber)) {
        throw new Error('Please enter a valid phone number');
      }

      // Generate a 6-digit code
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      
      // Store the code in the database with 10-minute expiration
      const { error } = await supabase
        .from('users')
        .update({
          phone_number: fullPhoneNumber,
          verification_code: code,
          verification_code_expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString()
        })
        .eq('id', userId);

      if (error) throw error;

      // In a real app, you would integrate with SMS service here
      console.log('Verification code:', code);
      
      setCodeSent(true);
      setResendTimer(15); // Start 15-second resend timer
    } catch (err: any) {
      setError(err.message || 'Failed to send verification code. Please try again.');
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  const verifyCode = async () => {
    try {
      setLoading(true);
      setError('');

      const { data, error } = await supabase
        .from('users')
        .select('verification_code, verification_code_expires_at')
        .eq('id', userId)
        .single();

      if (error) throw error;

      if (!data || !data.verification_code || !data.verification_code_expires_at) {
        throw new Error('No verification code found');
      }

      if (new Date(data.verification_code_expires_at) < new Date()) {
        throw new Error('Verification code has expired');
      }

      if (data.verification_code !== verificationCode) {
        throw new Error('Invalid verification code');
      }

      // Update verification status
      const { error: updateError } = await supabase
        .from('users')
        .update({
          phone_verified: true,
          verification_code: null,
          verification_code_expires_at: null
        })
        .eq('id', userId);

      if (updateError) throw updateError;

      setIsVerified(true);
      // Add animation delay before redirecting
      setTimeout(() => {
        onVerified();
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'Verification failed. Please try again.');
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handlePhoneNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Remove any non-digit characters
    const cleaned = e.target.value.replace(/\D/g, '');
    setPhoneNumber(cleaned);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-100 rounded-full mb-4">
              {isVerified ? (
                <div className="animate-[bounce_1s_ease-in-out]">
                  <Check className="h-8 w-8 text-green-600" />
                </div>
              ) : (
                <Phone className="h-8 w-8 text-indigo-600" />
              )}
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Phone Verification</h2>
            <p className="text-gray-600 mt-2">
              {!codeSent
                ? 'Please enter your phone number to verify your account'
                : 'Enter the verification code sent to your phone'}
            </p>
          </div>

          {isVerified ? (
            <div className="text-center">
              <div className="mb-4">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full">
                  <Check className="h-8 w-8 text-green-600 animate-[bounce_1s_ease-in-out]" />
                </div>
              </div>
              <p className="text-green-600 font-medium">Phone number verified successfully!</p>
              <p className="text-gray-500 text-sm mt-2">Redirecting you...</p>
            </div>
          ) : (
            <div className="space-y-6">
              {!codeSent ? (
                <>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                      Phone Number
                    </label>
                    <div className="mt-1 flex rounded-md shadow-sm">
                      {/* Country Code Selector */}
                      <div className="relative" id="country-dropdown">
                        <button
                          type="button"
                          onClick={() => setShowCountryDropdown(!showCountryDropdown)}
                          className="inline-flex items-center px-3 py-2 border border-r-0 border-gray-300 rounded-l-md bg-gray-50 text-gray-500 sm:text-sm hover:bg-gray-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        >
                          <span className="mr-2">{selectedCountry.flag}</span>
                          <span className="mr-2">{selectedCountry.dial_code}</span>
                          <ChevronDown className="h-4 w-4" />
                        </button>
                        
                        {/* Dropdown Menu */}
                        {showCountryDropdown && (
                          <div className="absolute z-10 mt-1 w-72 bg-white shadow-lg max-h-60 rounded-md py-1 text-base ring-1 ring-black ring-opacity-5 overflow-auto focus:outline-none sm:text-sm">
                            {countries.map((country) => (
                              <button
                                key={country.code}
                                className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center space-x-3"
                                onClick={() => {
                                  setSelectedCountry(country);
                                  setShowCountryDropdown(false);
                                }}
                              >
                                <span>{country.flag}</span>
                                <span>{country.name}</span>
                                <span className="text-gray-500">{country.dial_code}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      
                      {/* Phone Number Input */}
                      <input
                        type="tel"
                        value={phoneNumber}
                        onChange={handlePhoneNumberChange}
                        className="flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-r-md border-gray-300 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        placeholder="Enter phone number"
                      />
                    </div>
                    <p className="mt-2 text-sm text-gray-500">
                      Enter your phone number without country code
                    </p>
                  </div>
                  <button
                    onClick={sendVerificationCode}
                    disabled={loading || !phoneNumber}
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <span className="flex items-center">
                        <Loader className="animate-spin -ml-1 mr-2 h-4 w-4" />
                        Sending...
                      </span>
                    ) : (
                      'Send Verification Code'
                    )}
                  </button>
                </>
              ) : (
                <>
                  <div>
                    <label htmlFor="code" className="block text-sm font-medium text-gray-700">
                      Verification Code
                    </label>
                    <div className="mt-1">
                      <input
                        type="text"
                        id="code"
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        placeholder="Enter 6-digit code"
                        maxLength={6}
                      />
                    </div>
                    <div className="mt-2 flex justify-between items-center">
                      <p className="text-sm text-gray-500">
                        Didn't receive the code?
                      </p>
                      <button
                        onClick={sendVerificationCode}
                        disabled={resendTimer > 0 || loading}
                        className="text-sm text-indigo-600 hover:text-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {resendTimer > 0 ? `Resend in ${resendTimer}s` : 'Resend Code'}
                      </button>
                    </div>
                  </div>
                  <button
                    onClick={verifyCode}
                    disabled={loading || verificationCode.length !== 6}
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <span className="flex items-center">
                        <Loader className="animate-spin -ml-1 mr-2 h-4 w-4" />
                        Verifying...
                      </span>
                    ) : (
                      'Verify Code'
                    )}
                  </button>
                </>
              )}

              {error && (
                <div className="rounded-md bg-red-50 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-red-700">{error}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
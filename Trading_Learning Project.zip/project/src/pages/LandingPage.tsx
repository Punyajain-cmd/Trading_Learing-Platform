import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Users, Trophy, BookOpen, Gift, IndianRupee, ArrowRight, Shield, Target, Award, BarChart, Zap, Heart } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="bg-gray-50">
      {/* Welcome Bonus Banner */}
      <div className="relative bg-gradient-to-r from-indigo-900 via-indigo-800 to-indigo-900 text-white overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute transform -rotate-6 -translate-x-1/4 -translate-y-1/4">
            <div className="w-[600px] h-[600px] bg-indigo-600/20 rounded-full blur-3xl"></div>
          </div>
          <div className="absolute transform rotate-12 translate-x-3/4 translate-y-1/4">
            <div className="w-[600px] h-[600px] bg-purple-600/20 rounded-full blur-3xl"></div>
          </div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Left side: Content */}
            <div className="space-y-6 text-center md:text-left">
              {/*
	      <div className="inline-flex items-center space-x-2 bg-white/10 rounded-full px-4 py-2">
                <Gift className="h-5 w-5 text-indigo-200" />
                <span className="text-sm font-medium text-indigo-100">Exclusive Welcome Offer</span>
              </div>
	      */}
              
              <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight">
                Start Trading on
		    <div className="mt-2 text-5xl md:text-6xl text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 via-purple-200 to-pink-200 animate-pulse">
                        BITMORE
                    </div>
              </h2>
              
              <div className="space-y-4">
                <div className="flex items-center justify-center md:justify-start space-x-2 text-lg">
                  <ArrowRight className="h-5 w-5 text-indigo-300" />
                  <span>Risk-free practice with virtual money</span>
                </div>
                <div className="flex items-center justify-center md:justify-start space-x-2 text-lg">
                  <ArrowRight className="h-5 w-5 text-indigo-300" />
                  <span>Real-time market conditions</span>
                </div>
                <div className="flex items-center justify-center md:justify-start space-x-2 text-lg">
                  <ArrowRight className="h-5 w-5 text-indigo-300" />
                  <span>Start real trading with just ₹9</span>
                </div>
              </div>

              <div className="pt-4">
                <Link
                  to="/auth"
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50 transition-colors duration-150 ease-in-out"
                >
                  Get Started Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </div>
            </div>

            {/* Right side: Images */}
            <div className="relative hidden md:block">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=600&h=400&q=80"
                  alt="Trading Dashboard"
                  className="rounded-lg shadow-xl transform rotate-2 hover:rotate-0 transition-transform duration-300"
                />
                <img
                  src="https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&w=300&h=200&q=80"
                  alt="Trading Graph"
                  className="absolute -bottom-10 -left-10 rounded-lg shadow-xl transform -rotate-3 hover:rotate-0 transition-transform duration-300"
                />
		{/*
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
                  <div className="text-indigo-900 font-semibold">Weekly Prize Pool</div>
                  <div className="text-2xl font-bold text-indigo-600">₹25 Lakhs</div>
                </div>
		*/}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Why Choose Us Section */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Why Choose Bitmore?
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Experience the perfect blend of learning and earning
            </p>
          </div>

          <div className="mt-20">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  icon: <Shield className="h-8 w-8 text-indigo-600" />,
                  title: "Risk-Free Learning",
                  description: "Practice trading with ₹10 Lakh virtual money without risking your capital"
                },
                {
                  icon: <BarChart className="h-8 w-8 text-indigo-600" />,
                  title: "Real Market Data",
                  description: "Experience live market conditions with real-time data and analytics"
                },
                {
                  icon: <Trophy className="h-8 w-8 text-indigo-600" />,
                  title: "Weekly Competitions",
                  description: "Compete in trading challenges with prizes up to ₹10 Lakh"
                },
                {
                  icon: <Zap className="h-8 w-8 text-indigo-600" />,
                  title: "Instant Start",
                  description: "Begin your trading journey immediately with just ₹9"
                },
                {
                  icon: <Users className="h-8 w-8 text-indigo-600" />,
                  title: "Community Support",
                  description: "Join a community of traders and learn from their experiences"
                },
                {
                  icon: <Heart className="h-8 w-8 text-indigo-600" />,
                  title: "Personalized Experience",
                  description: "Get customized learning paths based on your trading style"
                }
              ].map((feature, index) => (
                <div
                  key={index}
                  className="relative group bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="relative">
                    <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      {feature.icon}
                    </div>
                    <h3 className="mt-4 text-xl font-semibold text-gray-900">
                      {feature.title}
                    </h3>
                    <p className="mt-2 text-gray-600">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>


    </div>
  );
}
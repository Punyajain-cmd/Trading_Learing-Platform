import React from 'react';
import { Clock, Share2, BookOpen, ExternalLink } from 'lucide-react';

// last updated on 15:00 11-04-2025;

export default function NewsPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Crypto News</h1>
          <div className="flex items-center space-x-4">
            <select className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
              <option>All Categories</option>
              <option>Markets</option>
              <option>Technology</option>
              <option>Regulation</option>
            </select>
          </div>
        </div>

        {/* Featured News */}
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="md:flex">
              <div className="md:flex-shrink-0">
                <img
                  className="h-48 w-full object-cover md:h-full md:w-48"
                  src="https://www.coindesk.com/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fs3y3vcno%2Fproduction%2F0228f48f345481c6eb51c437e52f21d1270dbcbc-4032x2268.jpg%3Fw%3D1920%26h%3D1080%26auto%3Dformat&w=1080&q=75"
                  alt="Top News"
                />
              </div>
              <div className="p-8">
                <div className="uppercase tracking-wide text-sm text-indigo-600 font-semibold">Breaking News</div>
                <a href="https://www.coindesk.com/policy/2025/04/07/president-trump-signs-resolution-erasing-irs-crypto-rule-targeting-defi" className="block mt-1 text-lg leading-tight font-medium text-black hover:underline">
                  President Trump Signs Resolution Erasing IRS Crypto Rule Targeting DeFi
                </a>
                <p className="mt-2 text-gray-500">
                The successful reversal of the Internal Revenue Service rule marks the first time the industry got a significant pro-crypto effort through Congress.
                </p>
                <div className="mt-4 flex items-center text-sm text-gray-500">
                  <Clock className="h-4 w-4 mr-1" />
                  10 hours ago
                  <span className="mx-2">•</span>
                  <BookOpen className="h-4 w-4 mr-1" />
                  5 min read
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* News Grid */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[
            {
              title: 'Bitcoin Reaches New All-Time High Amid Institutional Adoption',
              category: 'Markets',
              image: 'https://images.unsplash.com/photo-1523961131990-5ea7c61b2107?w=300&h=200&fit=crop',
              timeAgo: '2 hours ago',
              readTime: '3 min read',
              excerpt: ''
            },
            {
              title: 'New Regulatory Framework Proposed for Cryptocurrency Trading',
              category: 'Regulation',
              image: 'https://images.unsplash.com/photo-1605792657660-596af9009e82?w=300&h=200&fit=crop',
              timeAgo: '6 hours ago',
              readTime: '4 min read',
              excerpt: ''
            },
            {
              title: 'Major DeFi Protocol Launches New Governance Token',
              category: 'DeFi',
              image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=300&h=200&fit=crop',
              timeAgo: '8 hours ago',
              readTime: '5 min read',
              excerpt: ''
            },
            {
              title: 'NFT Market Shows Signs of Recovery After Recent Downturn',
              category: 'NFTs',
              image: 'https://images.unsplash.com/photo-1620321023374-d1a68fbc720d?w=300&h=200&fit=crop',
              timeAgo: '10 hours ago',
              readTime: '4 min read',
              excerpt: ''
            },
            {
              title: 'New Layer 2 Solution Promises Lower Gas Fees',
              category: 'Technology',
              image: 'https://images.unsplash.com/photo-1639322537228-f710d846310a?w=300&h=200&fit=crop',
              timeAgo: '12 hours ago',
              readTime: '6 min read',
              excerpt: ''
            },
            {
              title: 'Major Bank Launches Cryptocurrency Trading Services',
              category: 'Business',
              image: 'https://images.unsplash.com/photo-1634704784915-aacf363b021f?w=300&h=200&fit=crop',
              timeAgo: '14 hours ago',
              readTime: '3 min read',
              excerpt: ''
            }
          ].map((article, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <img
                className="h-48 w-full object-cover"
                src={article.image}
                alt={article.title}
              />
              <div className="p-6">
                <div className="flex items-center text-sm text-indigo-600 mb-2">
                  <span className="font-semibold">{article.category}</span>
                </div>
                <a href="https://www.coindesk.com/daybook-us/2025/04/11/crypto-daybook-americas-bitcoin-defies-peak-fear-as-u-s-dollar-plunges-over-trump-s-china-trade-war" className="block text-xl font-semibold text-gray-900 hover:text-indigo-600 mb-2">
                  {article.title}
                </a>
                <p className="text-gray-500 text-sm mb-4">
                  {article.excerpt}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    {article.timeAgo}
                    <span className="mx-2">•</span>
                    <BookOpen className="h-4 w-4 mr-1" />
                    {article.readTime}
                  </div>
                  <div className="flex space-x-2">
                    <button className="text-gray-400 hover:text-indigo-600">
                      <Share2 className="h-5 w-5" />
                    </button>
                    <button className="text-gray-400 hover:text-indigo-600">
                      <ExternalLink className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Load More Button 
        <div className="mt-8 text-center">
          <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
            Load More News
          </button>
        </div>
	*/}
      </div>
    </div>
  );
}
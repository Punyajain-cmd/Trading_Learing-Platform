import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Trophy, TrendingUp, TrendingDown, DollarSign, BarChart2, Clock, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';
import LivePriceChart from '../components/LivePriceChart';

interface EventParticipation {
  id: string;
  event_id: string;
  current_balance: number;
  created_at: string;
  trading_events: {
    title: string;
    description: string;
    start_time: string;
    end_time: string;
    status: string;
    theme_id: string;
  };
  trading_positions: {
    id: string;
    crypto_symbol: string;
    amount: number;
    entry_price: number;
    created_at: string;
  }[];
}

export default function MyEventsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [participations, setParticipations] = useState<EventParticipation[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalPortfolioValue, setTotalPortfolioValue] = useState(0);
  const [bestPerformingEvent, setBestPerformingEvent] = useState<EventParticipation | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    fetchParticipations();
  }, [user]);

  const fetchParticipations = async () => {
    try {
      const { data, error } = await supabase
        .from('event_participants')
        .select('*, trading_events (*)')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Fetch trading positions separately
      const positions = await Promise.all(
        data.map(async (participation) => {
          const { data: posData } = await supabase
            .from('trading_positions')
            .select('id, crypto_symbol, amount, entry_price, created_at')
            .eq('event_id', participation.event_id)
            .eq('user_id', user?.id);
          
          return {
            ...participation,
            trading_positions: posData || []
          };
        })
      );

      setParticipations(positions);

      // Calculate total portfolio value
      const totalValue = data?.reduce((sum, participation) => 
        sum + participation.current_balance, 0) || 0;
      setTotalPortfolioValue(totalValue);

      // Find best performing event
      const bestEvent = data?.reduce((best, current) => {
        const initialBalance = 1000000; // ₹10 Lakh
        const currentReturn = ((current.current_balance - initialBalance) / initialBalance) * 100;
        const bestReturn = best ? ((best.current_balance - initialBalance) / initialBalance) * 100 : -Infinity;
        return currentReturn > bestReturn ? current : best;
      }, null as EventParticipation | null);
      
      setBestPerformingEvent(bestEvent);

    } catch (error) {
      console.error('Error fetching participations:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">My Trading Events</h1>
          <p className="mt-2 text-gray-600">
            Track your performance across all trading events
          </p>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <Trophy className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm text-gray-500">Total Events Joined</p>
                <p className="text-xl font-semibold text-gray-900">
                  {participations.length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <DollarSign className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm text-gray-500">Total Portfolio Value</p>
                <p className="text-xl font-semibold text-gray-900">
                  ₹{totalPortfolioValue.toLocaleString()}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <TrendingUp className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm text-gray-500">Best Performance</p>
                {bestPerformingEvent && (
                  <p className="text-xl font-semibold text-gray-900">
                    {(((bestPerformingEvent.current_balance - 1000000) / 1000000) * 100).toFixed(2)}%
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <Clock className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm text-gray-500">Active Events</p>
                <p className="text-xl font-semibold text-gray-900">
                  {participations.filter(p => p.trading_events.status === 'active').length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Event List */}
        <div className="space-y-6">
          {participations.map((participation) => (
            <div key={participation.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {participation.trading_events.title}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {participation.trading_events.description}
                    </p>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                    participation.trading_events.status === 'active'
                      ? 'bg-green-100 text-green-800'
                      : participation.trading_events.status === 'upcoming'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {participation.trading_events.status.charAt(0).toUpperCase() + 
                     participation.trading_events.status.slice(1)}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-500">Current Balance</p>
                    <p className="text-lg font-semibold text-gray-900">
                      ₹{participation.current_balance.toLocaleString()}
                    </p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-500">Profit/Loss</p>
                    <p className={`text-lg font-semibold ${
                      participation.current_balance >= 1000000
                        ? 'text-green-600'
                        : 'text-red-600'
                    }`}>
                      {participation.current_balance >= 1000000 ? '+' : ''}
                      ₹{(participation.current_balance - 1000000).toLocaleString()}
                      <span className="text-sm">
                        ({(((participation.current_balance - 1000000) / 1000000) * 100).toFixed(2)}%)
                      </span>
                    </p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-500">Start Date</p>
                    <p className="text-lg font-semibold text-gray-900">
                      {format(new Date(participation.trading_events.start_time), 'PP')}
                    </p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-500">End Date</p>
                    <p className="text-lg font-semibold text-gray-900">
                      {format(new Date(participation.trading_events.end_time), 'PP')}
                    </p>
                  </div>
                </div>

                {/* Top Performing Coins */}
                {participation.trading_positions && participation.trading_positions.length > 0 && (
                  <div className="mb-6">
                    <h4 className="text-sm font-medium text-gray-700 mb-4">Top Performing Coins</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {participation.trading_positions
                        .sort((a, b) => {
                          const aProfit = (a.amount * a.entry_price);
                          const bProfit = (b.amount * b.entry_price);
                          return bProfit - aProfit;
                        })
                        .slice(0, 3)
                        .map((position, index) => (
                          <div key={index} className="bg-gray-50 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium">{position.crypto_symbol}</span>
                              <span className="text-sm text-gray-500">
                                {position.amount.toFixed(4)} coins
                              </span>
                            </div>
                            <div className="h-16">
                              <LivePriceChart
                                symbol={position.crypto_symbol}
                                height="100%"
                                showAxes={false}
                              />
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                {participation.trading_events.status === 'active' && (
                  <button
                    onClick={() => navigate(`/live-games?event=${participation.event_id}`)}
                    className="w-full flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                  >
                    Continue Trading
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          ))}

          {participations.length === 0 && (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Events Joined Yet
              </h3>
              <p className="text-gray-500 mb-4">
                Join a trading event to start competing and tracking your performance
              </p>
              <button
                onClick={() => navigate('/live-games')}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
              >
                Browse Events
                <ArrowRight className="ml-2 h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
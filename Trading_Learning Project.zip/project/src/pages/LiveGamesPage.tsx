import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Calendar, Users, Clock, TrendingUp, AlertCircle, ChevronRight, LogIn, Trophy, Target, Rocket } from 'lucide-react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import EventTradingInterface from '../components/EventTradingInterface';

// Event themes with allowed coins
const EVENT_THEMES = {
  'defi-trading': {
    name: 'DeFi Trading Challenge',
    description: 'Trade popular DeFi tokens and compete for the top spot. Master the decentralized finance market!',
    allowedCoins: ['uni', 'aave', 'comp', 'mkr', 'snx', 'sushi', 'cake', 'crv', 'bal', 'yfi']
  },
  'layer1-battle': {
    name: 'Layer 1 Battle',
    description: 'Trade major blockchain platforms and predict which Layer 1 will dominate the market!',
    allowedCoins: ['eth', 'sol', 'ada', 'avax', 'dot', 'near', 'atom', 'ftm', 'algo', 'matic']
  },
  'metaverse-gaming': {
    name: 'Metaverse & Gaming',
    description: 'Invest in the future of gaming and virtual worlds with these metaverse tokens!',
    allowedCoins: ['mana', 'sand', 'axs', 'enj', 'gala', 'ilv', 'alice', 'gmt', 'enjin', 'imx']
  },
  'scaling-solutions': {
    name: 'Scaling Solutions',
    description: 'Trade Layer 2 and scaling solution tokens. Which scaling solution will win the race?',
    allowedCoins: ['op', 'arb', 'imx', 'lrc', 'zks', 'metis', 'dydx', 'skl', 'matic', 'ftm']
  }
};

interface TradingEvent {
  id: string;
  title: string;
  description: string;
  start_time: string;
  end_time: string;
  max_participants: number;
  initial_balance: number;
  status: 'upcoming' | 'active' | 'completed';
  theme_id: keyof typeof EVENT_THEMES;
}

export default function LiveGamesPage() {
  const [events, setEvents] = useState<TradingEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [eventToJoin, setEventToJoin] = useState<TradingEvent | null>(null);
  const [userEvents, setUserEvents] = useState<string[]>([]);
  const [eventParticipants, setEventParticipants] = useState<{ [key: string]: number }>({});
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchEvents();
    fetchEventParticipants();
    if (user) {
      fetchUserEvents();
    }
  }, []);

  async function fetchEventParticipants() {
    try {
      const { data, error } = await supabase
        .from('event_participants')
        .select('event_id');

      if (error) throw error;

      // Count participants for each event
      const counts = data.reduce((acc: { [key: string]: number }, item) => {
        acc[item.event_id] = (acc[item.event_id] || 0) + 1;
        return acc;
      }, {});

      setEventParticipants(counts);
    } catch (error) {
      console.error('Error fetching event participants:', error);
    }
  }

  async function fetchUserEvents() {
    try {
      const { data, error } = await supabase
        .from('event_participants')
        .select('event_id')
        .eq('user_id', user?.id);

      if (error) throw error;
      setUserEvents(data?.map(p => p.event_id) || []);
    } catch (error) {
      console.error('Error fetching user events:', error);
    }
  }

  async function fetchEvents() {
    try {
      const { data, error } = await supabase
        .from('trading_events')
        .select('*')
        .order('start_time', { ascending: true });

      if (error) throw error;
      setEvents(data || []);
    } catch (error) {
      console.error('Error fetching events:', error);
    } finally {
      setLoading(false);
    }
  }

  async function joinEvent(eventId: string) {
    if (!user) {
      setAlertMessage('Please sign in to join trading events');
      setShowAlert(true);
      
      // Add a delay before redirecting to auth page
      const timer = setTimeout(() => {
        navigate('/auth', { 
          state: { 
            returnTo: `/live-games`,
            eventId: eventId 
          }
        });
      }, 2000);
      
      return () => clearTimeout(timer);
    }

    try {
      // Check if user is already participating
      const { data: existingParticipation } = await supabase
        .from('event_participants')
        .select('*')
        .eq('event_id', eventId)
        .eq('user_id', user.id);

      if (existingParticipation && existingParticipation.length > 0) {
        setAlertMessage('You are already participating in this event!');
        setShowAlert(true);
        return;
      }

      // Check if event is full
      const { data: event } = await supabase
        .from('trading_events')
        .select('max_participants')
        .eq('id', eventId)
        .single();

      const { data: participantCount } = await supabase
        .from('event_participants')
        .select('id', { count: 'exact' })
        .eq('event_id', eventId);

      if (participantCount && event && participantCount.length >= event.max_participants) {
        setAlertMessage('This event is full. Please try another event.');
        setShowAlert(true);
        return;
      }

      // Join the event
      const { error } = await supabase
        .from('event_participants')
        .insert([
          {
            event_id: eventId,
            user_id: user.id,
            current_balance: 1000000 // ₹10 Lakh starting balance
          }
        ]);

      if (error) throw error;
      
      setAlertMessage('Successfully joined the event!');
      setUserEvents(prev => [...prev, eventId]);
      setShowAlert(true);
      setSelectedEvent(eventId);

    } catch (error) {
      console.error('Error joining event:', error);
      setAlertMessage('Failed to join event. Please try again.');
      setShowAlert(true);
    }
  }

  const handleConfirmJoin = async () => {
    if (!eventToJoin) return;
    
    await joinEvent(eventToJoin.id);
    setShowConfirmation(false);
    setEventToJoin(null);
  };

  const handleEventAction = (event: TradingEvent) => {
    if (!user) {
      setAlertMessage('Please sign in to join trading events');
      setShowAlert(true);
      setTimeout(() => {
        navigate('/auth');
      }, 2000);
      return;
    }
    
    if (event.status === 'upcoming' && !userEvents.includes(event.id)) {
      setEventToJoin(event);
      setShowConfirmation(true);
    } else {
      setSelectedEvent(event.id);
    }
  }

  if (selectedEvent && user) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onClick={() => setSelectedEvent(null)}
            className="mb-8 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-600 bg-indigo-100 hover:bg-indigo-200"
          >
            <ChevronRight className="h-5 w-5 mr-2 transform rotate-180" />
            Back to Events
          </button>
          {events.find(e => e.id === selectedEvent)?.theme_id && (
            <EventTradingInterface
              eventId={selectedEvent}
              userId={user.id}
              eventTheme={EVENT_THEMES[events.find(e => e.id === selectedEvent)!.theme_id]}
            />
          )}
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section with Parallax */}
      <div className="relative h-[500px] overflow-hidden bg-gradient-to-br from-indigo-900 via-indigo-800 to-purple-900">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1605792657660-596af9009e82?auto=format&fit=crop&w=2000&q=80"
            alt="Trading Background"
            className="w-full h-full object-cover opacity-10 transform scale-110 motion-safe:animate-subtle-zoom"
          />
          {/* Gradient Overlays */}
          <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/80 via-transparent to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 to-purple-600/20" />
          {/* Decorative Elements */}
          <div className="absolute -left-20 -top-20 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl" />
          <div className="absolute -right-20 -bottom-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center text-center z-10">
          <h1 className="text-5xl font-extrabold text-white sm:text-6xl md:text-7xl animate-fade-in bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-100 to-purple-100">
            Live Trading Events
          </h1>
          <p className="mt-6 text-xl text-indigo-100 max-w-3xl mx-auto animate-fade-in font-medium leading-relaxed tracking-wide" style={{animationDelay: '0.2s'}}>
            Join live trading events and compete with traders worldwide for real prizes
          </p>
          <div className="mt-12 grid grid-cols-3 gap-8 max-w-3xl mx-auto animate-fade-in" style={{animationDelay: '0.4s'}}>
            <div className="text-center">
              <div className="text-4xl font-bold text-white bg-white/10 backdrop-blur-sm rounded-xl p-4 mb-2">₹10L</div>
              <div className="text-indigo-100 font-medium">Starting Capital</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white bg-white/10 backdrop-blur-sm rounded-xl p-4 mb-2">100+</div>
              <div className="text-indigo-100 font-medium">Active Traders</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white bg-white/10 backdrop-blur-sm rounded-xl p-4 mb-2">₹25L</div>
              <div className="text-indigo-100 font-medium">Weekly Prizes</div>
            </div>
          </div>
        </div>
        {/* Bottom Gradient */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-gray-50 to-transparent"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-10 pb-12">
        {/* Alert Message */}
        {showAlert && (
          <div className="fixed top-4 right-4 w-96 bg-white rounded-lg shadow-xl overflow-hidden z-50 animate-fade-in">
            <div className="p-4">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-6 w-6 text-indigo-600" />
                </div>
                <div className="ml-3 w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900">{alertMessage}</p>
                </div>
                <div className="ml-4 flex-shrink-0 flex">
                  <button
                    onClick={() => setShowAlert(false)}
                    className="bg-white rounded-md inline-flex text-gray-400 hover:text-gray-500"
                  >
                    <span className="sr-only">Close</span>
                    <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
            <div className="bg-indigo-100 h-1">
              <div className="bg-indigo-600 h-1 animate-[shrink_2s_linear]"></div>
            </div>
          </div>
        )}

        {/* Confirmation Modal */}
        {showConfirmation && eventToJoin && (
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Confirm Participation
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                Are you sure you want to join "{eventToJoin.title}"? You'll start with ₹{eventToJoin.initial_balance.toLocaleString()} in virtual money.
              </p>
              <div className="flex justify-end space-x-4">
                <button
                  onClick={() => {
                    setShowConfirmation(false);
                    setEventToJoin(null);
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 border border-gray-300 rounded-md"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmJoin}
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
                >
                  Confirm & Join
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="mt-12 grid gap-5 max-w-lg mx-auto lg:grid-cols-3 lg:max-w-none">
          {events.map((event) => (
            <div 
              key={event.id}
              className="flex flex-col rounded-lg shadow-lg overflow-hidden bg-white transform hover:-translate-y-1 transition-all duration-300 hover:shadow-xl"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={
                    event.theme_id === 'defi-trading'
                      ? 'https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&w=800&h=400'
                      : event.theme_id === 'layer1-battle'
                      ? 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=800&h=400'
                      : event.theme_id === 'metaverse-gaming'
                      ? 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?auto=format&fit=crop&w=800&h=400'
                      : event.theme_id === 'scaling-solutions'
                      ? 'https://images.unsplash.com/photo-1639322537504-6427a16b0a28?auto=format&fit=crop&w=800&h=400'
                      : event.status === 'active'
                      ? 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=800&h=400'
                      : 'https://images.unsplash.com/photo-1634704784915-aacf363b021f?auto=format&fit=crop&w=800&h=400'
                  }
                  alt={event.title}
                  className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-500 motion-safe:animate-subtle-zoom"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent"></div>
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                    event.status === 'upcoming' ? 'bg-yellow-100 text-yellow-800' :
                    event.status === 'active' ? 'bg-green-100 text-green-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {event.status === 'upcoming' && <Target className="w-3 h-3 mr-1" />}
                    {event.status === 'active' && <Rocket className="w-3 h-3 mr-1" />}
                    {event.status === 'completed' && <Trophy className="w-3 h-3 mr-1" />}
                    {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                  </div>
                </div>
              </div>
              <div className="flex-1 p-6 flex flex-col justify-between">
                <div className="flex-1">
                  <div className="block mt-2">
                    <p className="text-xl font-semibold text-gray-900 animate-fade-in" style={{animationDelay: '0.1s'}}>{event.title}</p>
                    <p className="mt-3 text-base text-gray-500 animate-fade-in" style={{animationDelay: '0.2s'}}>{event.description}</p>
                  </div>
                </div>

                <div className="mt-6 space-y-3">
                  <div className="flex items-center text-sm text-gray-500 animate-fade-in" style={{animationDelay: '0.3s'}}>
                    <Calendar className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                    <span>Starts: {format(new Date(event.start_time), 'PPp')}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-500 animate-fade-in" style={{animationDelay: '0.4s'}}>
                    <Clock className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                    <span>Ends: {format(new Date(event.end_time), 'PPp')}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-500 animate-fade-in" style={{animationDelay: '0.5s'}}>
                    <div className="w-full">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center">
                          <Users className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                          <span>Participants: {eventParticipants[event.id] || 0}/{event.max_participants}</span>
                        </div>
                        <span className="text-xs font-medium text-indigo-600">
                          {Math.round(((eventParticipants[event.id] || 0) / event.max_participants) * 100)}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                          style={{
                            width: `${Math.min(((eventParticipants[event.id] || 0) / event.max_participants) * 100, 100)}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center text-sm text-gray-500 animate-fade-in" style={{animationDelay: '0.6s'}}>
                    <TrendingUp className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                    <span>Initial Balance: ${event.initial_balance.toLocaleString()}</span>
                  </div>
                </div>

                <div className="mt-6 animate-fade-in" style={{animationDelay: '0.7s'}}>
                  <button
                    onClick={() => handleEventAction(event)}
                    disabled={event.status !== 'upcoming' || loading}
                    className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                      userEvents.includes(event.id)
                        ? 'bg-green-600 hover:bg-green-700'
                        : event.status === 'upcoming'
                          ? 'bg-indigo-600 hover:bg-indigo-700'
                          : 'bg-gray-400 cursor-not-allowed'
                    }`}
                  >
                    {loading ? (
                      <div className="flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Processing...
                      </div>
                    ) : (userEvents.includes(event.id) || event.status === 'active') && userEvents.includes(event.id) ? (
                      <>
                        <TrendingUp className="h-4 w-4 mr-2" />
                        Continue Trading
                      </>
                    ) : (
                      <>
                        {!user && event.status === 'upcoming' && <LogIn className="h-4 w-4 mr-2" />}
                        {event.status === 'upcoming' ? (user ? 'Join Event' : 'Sign in to Join') : 'Event ' + event.status}
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
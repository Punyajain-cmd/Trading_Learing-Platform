import React, { useEffect, useRef } from 'react';
import { Gift, BookOpen, TrendingUp, Trophy, Target, Rocket, ArrowRight, BarChart, Users, Shield } from 'lucide-react';

export default function HowItWorksPage() {
  const parallaxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!parallaxRef.current) return;
      const scrolled = window.scrollY;
      parallaxRef.current.style.transform = `translateY(${scrolled * 0.5}px)`;
      parallaxRef.current.style.opacity = `${1 - scrolled / 1000}`;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section with Parallax */}
      <div className="relative overflow-hidden bg-indigo-900 text-white h-screen flex items-center">
        <div ref={parallaxRef} className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1642790551116-18e150f248e3?auto=format&fit=crop&w=2000&q=80"
            alt="Trading Background"
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-extrabold mb-6 animate-fade-in">
            Your Journey to Trading Mastery
          </h1>
          <p className="text-xl md:text-2xl text-indigo-200 max-w-3xl mx-auto animate-fade-in" style={{animationDelay: '0.2s'}}>
            Master the art of trading through our comprehensive learning platform. Start with virtual money and compete to win real prizes.
          </p>
          <div className="mt-8 animate-fade-in" style={{animationDelay: '0.4s'}}>
            <a
              href="#learn-more"
              className="inline-flex items-center px-8 py-3 border-2 border-white text-lg font-medium rounded-md text-white hover:bg-white hover:text-indigo-900 transition-colors duration-300"
            >
              Learn More
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </div>
        </div>
      </div>

      {/* Introduction Section */}
      <div id="learn-more" className="bg-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Why Choose Bitmore?
            </h2>
            <p className="mt-4 text-xl text-gray-500">
              We combine cutting-edge technology with expert knowledge to provide you with the best trading learning experience. Our platform is designed to help both beginners and experienced traders enhance their skills in a risk-free environment.
            </p>
          </div>

          <div className="mt-20 grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: <Shield className="h-8 w-8" />,
                title: "Risk-Free Learning",
                description: "Practice with ₹10 Lakh virtual money without any real financial risk. Perfect your strategies before trading with real money."
              },
              {
                icon: <BarChart className="h-8 w-8" />,
                title: "Real Market Data",
                description: "Experience live market conditions with real-time data and advanced charting tools. Learn to analyze market trends effectively."
              },
              {
                icon: <Users className="h-8 w-8" />,
                title: "Expert Community",
                description: "Join a community of traders, share insights, and learn from experienced professionals through our interactive platform."
              }
            ].map((feature, index) => (
              <div
                key={index}
                className="relative group bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="relative">
                  <div className="w-14 h-14 bg-indigo-100 rounded-lg flex items-center justify-center text-indigo-600 group-hover:scale-110 transition-transform duration-300">
                    {feature.icon}
                  </div>
                  <h3 className="mt-6 text-xl font-bold text-gray-900">
                    {feature.title}
                  </h3>
                  <p className="mt-4 text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Timeline Section with Scroll Animation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Your Learning Journey
          </h2>
          <p className="mt-4 text-xl text-gray-500 max-w-3xl mx-auto">
            Follow our structured learning path to become a confident trader. Each step is designed to build your knowledge and skills progressively.
          </p>
        </div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="hidden lg:block absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-gradient-to-b from-indigo-400 via-purple-400 to-pink-400" />

          {/* Timeline Steps */}
          {[
            {
              icon: <Gift />,
              title: "Step 1: Get Started",
              description: "Begin your journey with ₹10 Lakh in virtual money. Learn the basics of our platform and set up your trading account.",
              details: [
                "Complete account registration",
                "Receive virtual trading capital",
                "Explore platform features"
              ],
              image: "https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?auto=format&fit=crop&w=600&h=400&q=80",
              align: "right"
            },
            {
              icon: <BookOpen />,
              title: "Step 2: Learn Fundamentals",
              description: "Master the essential concepts of trading through our comprehensive educational resources.",
              details: [
                "Understanding market basics",
                "Technical analysis fundamentals",
                "Risk management principles"
              ],
              image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=600&h=400&q=80",
              align: "left"
            },
            {
              icon: <TrendingUp />,
              title: "Step 3: Practice Trading",
              description: "Apply your knowledge in real market conditions using virtual money to develop and test strategies.",
              details: [
                "Execute practice trades",
                "Analyze market movements",
                "Develop trading strategies"
              ],
              image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&w=600&h=400&q=80",
              align: "right"
            },
            {
              icon: <Trophy />,
              title: "Step 4: Join Competitions",
              description: "Test your skills against other traders in weekly competitions with real cash prizes.",
              details: [
                "Participate in trading challenges",
                "Compete for prizes",
                "Learn from top performers"
              ],
              image: "https://images.unsplash.com/photo-1579226905180-636b76d96082?auto=format&fit=crop&w=600&h=400&q=80",
              align: "left"
            }
          ].map((step, index) => (
            <div key={index} className="relative mb-32 last:mb-0 opacity-0 translate-y-10" style={{
              animation: `fade-slide-up 0.6s ease-out ${index * 0.2}s forwards`
            }}>
              <div className={`lg:flex items-center ${step.align === 'left' ? 'lg:flex-row' : 'lg:flex-row-reverse'}`}>
                {/* Content */}
                <div className={`lg:w-1/2 ${step.align === 'left' ? 'lg:pr-16' : 'lg:pl-16'}`}>
                  <div className="bg-white p-8 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300">
                    <div className="flex items-center mb-6">
                      <div className="flex-shrink-0">
                        <div className="h-14 w-14 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600">
                          {step.icon}
                        </div>
                      </div>
                      <h3 className="ml-4 text-2xl font-bold text-gray-900">{step.title}</h3>
                    </div>
                    <p className="text-lg text-gray-600 mb-6">{step.description}</p>
                    <ul className="space-y-3">
                      {step.details.map((detail, i) => (
                        <li key={i} className="flex items-center text-gray-600">
                          <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Timeline Marker */}
                <div className="hidden lg:block absolute left-1/2 transform -translate-x-1/2">
                  <div className="w-10 h-10 bg-indigo-600 rounded-full border-4 border-white shadow-lg" />
                </div>

                {/* Image */}
                <div className="lg:w-1/2 mt-8 lg:mt-0">
                  <div className={`rounded-xl overflow-hidden shadow-xl transform hover:scale-105 transition-all duration-300 ${
                    step.align === 'left' ? 'lg:ml-16' : 'lg:mr-16'
                  }`}>
                    <img
                      src={step.image}
                      alt={step.title}
                      className="w-full h-80 object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-indigo-900 to-purple-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-extrabold mb-8">
            Ready to Begin Your Trading Journey?
          </h2>
          <p className="text-xl text-indigo-200 mb-12 max-w-3xl mx-auto">
            Join thousands of traders who have already started their path to financial mastery. Get your ₹10 Lakh virtual trading capital today.
          </p>
          <a
            href="/auth"
            className="inline-flex items-center px-8 py-4 border-2 border-white text-lg font-medium rounded-md text-indigo-900 bg-white hover:bg-transparent hover:text-white transition-colors duration-300"
          >
            Start Trading Now
            <ArrowRight className="ml-2 h-6 w-6" />
          </a>
        </div>
      </div>

      <style>{`
        @keyframes fade-slide-up {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
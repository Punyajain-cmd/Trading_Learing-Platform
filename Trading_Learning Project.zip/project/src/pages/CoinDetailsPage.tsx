import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getCryptoPrices, CryptoPrice } from '../lib/api';
import LivePriceChart from '../components/LivePriceChart';
import { TrendingUp, TrendingDown, Globe, DollarSign, BarChart2, Activity } from 'lucide-react';

export default function CoinDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const [coin, setCoin] = useState<CryptoPrice | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCoinData = async () => {
      try {
        const allCoins = await getCryptoPrices();
        const foundCoin = allCoins.find(c => c.id === id);
        if (foundCoin) {
          setCoin(foundCoin);
        }
      } catch (error) {
        console.error('Error fetching coin data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCoinData();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!coin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-500">Coin not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Coin Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <img src={coin.image} alt={coin.name} className="h-16 w-16 rounded-full" />
              <div className="ml-4">
                <h1 className="text-2xl font-bold text-gray-900">{coin.name}</h1>
                <p className="text-gray-500">{coin.symbol.toUpperCase()}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-gray-900">
                ${coin.current_price.toLocaleString()}
              </div>
              <div className={`flex items-center justify-end ${
                coin.price_change_percentage_24h >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {coin.price_change_percentage_24h >= 0 ? (
                  <TrendingUp className="h-5 w-5 mr-1" />
                ) : (
                  <TrendingDown className="h-5 w-5 mr-1" />
                )}
                <span className="font-semibold">
                  {coin.price_change_percentage_24h >= 0 ? '+' : ''}
                  {coin.price_change_percentage_24h.toFixed(2)}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Price Chart */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Price Chart</h2>
          <div className="h-96">
            <LivePriceChart symbol={coin.symbol} height="100%" />
          </div>
        </div>

        {/* Market Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <BarChart2 className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm text-gray-500">Market Cap</p>
                <p className="text-xl font-semibold text-gray-900">
                  ${coin.market_cap.toLocaleString()}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <Activity className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm text-gray-500">24h Trading Volume</p>
                <p className="text-xl font-semibold text-gray-900">
                  ${coin.total_volume.toLocaleString()}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <DollarSign className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm text-gray-500">Circulating Supply</p>
                <p className="text-xl font-semibold text-gray-900">
                  {coin.circulating_supply.toLocaleString()} {coin.symbol.toUpperCase()}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Price Statistics */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Price Statistics</h2>
          <div className="space-y-4">
            <div className="flex justify-between py-3 border-b">
              <span className="text-gray-500">24h High</span>
              <span className="font-medium text-gray-900">${coin.high_24h?.toLocaleString() ?? 'N/A'}</span>
            </div>
            <div className="flex justify-between py-3 border-b">
              <span className="text-gray-500">24h Low</span>
              <span className="font-medium text-gray-900">${coin.low_24h?.toLocaleString() ?? 'N/A'}</span>
            </div>
            <div className="flex justify-between py-3 border-b">
              <span className="text-gray-500">All Time High</span>
              <div className="text-right">
                <div className="font-medium text-gray-900">${coin.ath?.toLocaleString() ?? 'N/A'}</div>
                <div className={`text-sm ${coin.ath_change_percentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {coin.ath_change_percentage >= 0 ? '+' : ''}
                  {coin.ath_change_percentage?.toFixed(2)}%
                </div>
              </div>
            </div>
            <div className="flex justify-between py-3">
              <span className="text-gray-500">Max Supply</span>
              <span className="font-medium text-gray-900">
                {coin.max_supply ? `${coin.max_supply.toLocaleString()} ${coin.symbol.toUpperCase()}` : 'No Max Supply'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
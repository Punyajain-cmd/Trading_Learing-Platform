import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { Wallet, TrendingUp, TrendingDown, DollarSign, BarChart2, PieChart as IconPie, Edit, X } from 'lucide-react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  AreaChart, Area, PieChart as RePieChart, Pie, Cell
} from 'recharts';
import { supabase } from '../lib/supabase'; // Ensure this path is correct
import { useAuth } from '../contexts/AuthContext'; // Ensure this path is correct
import { useNavigate } from 'react-router-dom';
import { getCryptoPrices, priceUpdates, CryptoPrice } from '../lib/api'; // Ensure this path is correct

// --- Interfaces ---
interface PortfolioAsset {
  id: string; crypto_symbol: string; amount: number; avg_buy_price: number;
  current_price?: number; name?: string; logo?: string; value?: number;
  profit_loss?: number; profit_loss_percentage?: number;
}
interface NewAssetState { symbol: string; amount: string; price: string; name: string; }
interface PortfolioHistoryPoint { timestamp: number; value: number; }
interface PortfolioDistributionPoint { name: string; value: number; percentage: number; color: string; }
interface EditingAssetState { amount: string; price: string; }

// --- Helper Functions ---
// Simple Pseudo-Random Number Generator (PRNG) - Mulberry32
function mulberry32(seed: number) {
    return function() {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    }
}
// Simple string hash function to create a seed
function simpleHash(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) { const char = str.charCodeAt(i); hash = ((hash << 5) - hash) + char; hash |= 0; }
  return hash;
}

// --- Component ---
export default function PortfolioPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  // --- State ---
  const [assets, setAssets] = useState<PortfolioAsset[]>([]);
  const [initialLoading, setInitialLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [availableCoins, setAvailableCoins] = useState<CryptoPrice[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);
  const [newAsset, setNewAsset] = useState<NewAssetState>({ symbol: '', amount: '', price: '', name: '' });
  const [chartTimeframe, setChartTimeframe] = useState('1W');
  const [portfolioData, setPortfolioData] = useState<PortfolioHistoryPoint[]>([]);
  const [portfolioDistribution, setPortfolioDistribution] = useState<PortfolioDistributionPoint[]>([]);
  const [stableColors, setStableColors] = useState<Record<string, string>>({});
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingAsset, setEditingAsset] = useState<PortfolioAsset | null>(null);
  const [editFormData, setEditFormData] = useState<EditingAssetState>({ amount: '', price: ''});

  // --- Memoized Calculations ---
  // Recalculate totals when assets change
  const { totalValue, totalProfitLoss, totalCostBasis } = useMemo(() => {
    let currentTotalValue = 0;
    let currentTotalCost = 0;
    assets.forEach(asset => {
      // Use enriched values if available, otherwise calculate cost basis only
      currentTotalValue += asset.value || 0;
      currentTotalCost += asset.amount * asset.avg_buy_price;
    });
    const currentTotalProfitLoss = currentTotalValue - currentTotalCost;
    return {
        totalValue: currentTotalValue,
        totalProfitLoss: currentTotalProfitLoss,
        totalCostBasis: currentTotalCost // Needed for P/L % calculation
    };
  }, [assets]);


  // --- Data Fetching and Management Callbacks ---
  // Fetch all available cryptocurrencies from the API
  const fetchAvailableCoins = useCallback(async () => {
    console.log('Fetching available coins...');
    try {
      const coins = await getCryptoPrices();
      setAvailableCoins(coins || []);
    } catch (error) {
      console.error('Error fetching available coins:', error);
      setAvailableCoins([]);
    }
  }, []);

  // Fetch user's portfolio assets from Supabase
  const fetchPortfolioAssets = useCallback(async () => {
    if (!user) return null;
    console.log('Fetching portfolio assets for user:', user.id);
    try {
      const { data, error } = await supabase
        .from('portfolio_assets')
        .select('id, crypto_symbol, amount, avg_buy_price')
        .eq('user_id', user.id);
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching portfolio assets:', error);
      return null;
    }
  }, [user]);

  // Enrich raw assets with live data and calculations
  const enrichAssets = useCallback((rawAssets: PortfolioAsset[], currentCoins: CryptoPrice[]): PortfolioAsset[] => {
    if (!rawAssets) return []; // Handle null case
    // Create a map for efficient lookup
    const coinMap = new Map(currentCoins.map(c => [c.symbol.toLowerCase(), c]));

    return rawAssets.map(asset => {
      const coinInfo = coinMap.get(asset.crypto_symbol.toLowerCase());
      const current_price = coinInfo?.current_price;
      const value = current_price !== undefined ? asset.amount * current_price : undefined;
      const costBasis = asset.amount * asset.avg_buy_price;
      const profit_loss = value !== undefined ? value - costBasis : undefined;
      // Ensure costBasis is not zero to avoid division by zero
      const profit_loss_percentage = value !== undefined && costBasis !== 0 ? (profit_loss / costBasis) * 100 : undefined;

      return {
        ...asset,
        current_price,
        name: coinInfo?.name ?? asset.crypto_symbol.toUpperCase(),
        logo: coinInfo?.image ?? '/placeholder-logo.png', // Provide a default/placeholder logo path
        value,
        profit_loss,
        profit_loss_percentage,
      };
    });
  }, []); // No dependencies needed if it's a pure function based on arguments

  // --- UseEffects for Data Flow ---
  // 1. Redirect if not logged in
  useEffect(() => { if (!user) navigate('/auth'); }, [user, navigate]);

  // 2. Fetch available coins once on mount (if user exists)
  useEffect(() => { if (user) fetchAvailableCoins(); }, [user, fetchAvailableCoins]);

  // 3. Initial load: Fetch assets, then enrich once coins are available
  useEffect(() => {
    if (user) {
      const loadInitialData = async () => {
        setInitialLoading(true);
        const rawAssets = await fetchPortfolioAssets();
        if (rawAssets !== null) {
            // Enrich only if coins are already available, otherwise enrichment happens in step 4's effect
            if (availableCoins.length > 0) {
                setAssets(enrichAssets(rawAssets, availableCoins));
            } else {
                // Store raw assets temporarily if coins aren't ready yet
                 setAssets(rawAssets); // Store raw, enrichment will happen below
            }
        } else {
          setAssets([]); // Handle fetch failure
        }
        setInitialLoading(false);
      };
      loadInitialData();
    } else {
        setAssets([]); // Clear assets if no user
        setInitialLoading(false);
    }
  }, [user, fetchPortfolioAssets]); // Removed availableCoins dependency here

  // 4. Enrich assets whenever availableCoins change (covers initial load enrichment too)
   useEffect(() => {
        if (availableCoins.length > 0 && assets.length > 0) {
             // Check if the current assets state actually needs enrichment (i.e., lacks 'value' field)
             if (assets.some(a => a.value === undefined)) {
                 console.log("Enriching assets after coins became available...");
                 setAssets(prevAssets => enrichAssets(prevAssets, availableCoins));
             }
        }
   }, [availableCoins, assets, enrichAssets]); // Depend on assets too, to catch the initial raw state

  // 5. Subscribe to price updates and re-enrich assets
  useEffect(() => {
    if (!user || availableCoins.length === 0) return; // Only subscribe when ready

    const subscription = priceUpdates.subscribe(update => {
      // Update the master list of available coins
      const updatedCoins = availableCoins.map(coin =>
        coin.symbol.toLowerCase() === update.symbol.toLowerCase()
          ? { ...coin, current_price: update.price }
          : coin
      );
      setAvailableCoins(updatedCoins); // Update the reference list

      // Re-enrich the current assets state with the updated coin list
      setAssets(prevAssets => enrichAssets(prevAssets, updatedCoins));
    });
    return () => subscription.unsubscribe();
    // Use updatedCoins directly in enrichAssets if availableCoins state update isn't fast enough
  }, [user, availableCoins, enrichAssets]); // Keep availableCoins dependency


  // --- Chart Data Generation Callbacks (MODIFIED for stability - kept from first snippet) ---

  // Generates a STABLE, deterministic historical shape based only on timeframe, then scales
  const generatePortfolioData = useCallback(() => {
    if (totalValue <= 0) { setPortfolioData([]); return; }

    const now = Date.now(); const data: PortfolioHistoryPoint[] = [];
    const timeframes = { '1D': 86400000, '1W': 604800000, '1M': 2592000000 };
    const duration = timeframes[chartTimeframe as keyof typeof timeframes];
    const points = 30; const interval = duration / points;
    let relativeValue = 100; // Start history shape relative to 100

    const seed = simpleHash(chartTimeframe); // Seed ensures shape is same for same timeframe
    const random = mulberry32(seed);
    const volatilityFactor = chartTimeframe === '1D' ? 0.03 : (chartTimeframe === '1W' ? 0.08 : 0.15);

    // Generate the historical relative shape
    for (let i = 0; i < points; i++) {
        const timestamp = now - (points - i) * interval;
        const randomChange = (random() - 0.5) * volatilityFactor;
        relativeValue = relativeValue * (1 + randomChange);
        data.push({ timestamp, value: Math.max(1, parseFloat(relativeValue.toFixed(2))) }); // Store relative value
    }

    // Scale the historical shape based on the current totalValue relative to the shape's end
    const shapeEndValue = data.length > 0 ? data[data.length - 1].value : 100;
    const scaleFactor = shapeEndValue !== 0 ? totalValue / shapeEndValue : 1; // Avoid division by zero

    const scaledHistoricalData = data.map(p => ({
        ...p,
        value: parseFloat((p.value * scaleFactor).toFixed(2))
    }));

    // Add the final point representing the exact current time and value
    scaledHistoricalData.push({ timestamp: now, value: parseFloat(totalValue.toFixed(2)) });

    setPortfolioData(scaledHistoricalData);
  }, [chartTimeframe, totalValue]); // Depends on timeframe and totalValue for scaling

  // Update Pie chart data (using stable colors)
  const updatePortfolioDistribution = useCallback(() => {
      if (totalValue <= 0 || assets.length === 0) {
          setPortfolioDistribution([]);
          return;
      }

      let currentColors = { ...stableColors }; // Copy existing stable colors
      const distribution: PortfolioDistributionPoint[] = assets
          .filter(a => a.value !== undefined && a.value > 0)
          .map(asset => {
              let color = currentColors[asset.crypto_symbol];
              if (!color) {
                  // Generate a new color if not found, using the deterministic PRNG seeded by symbol
                  const seed = simpleHash(asset.crypto_symbol);
                  const random = mulberry32(seed);
                  // Generate aesthetically pleasing HSL colors
                  color = `hsl(${Math.floor(random() * 360)}, ${70 + Math.floor(random() * 20)}%, ${50 + Math.floor(random() * 10)}%)`;
                  currentColors[asset.crypto_symbol] = color; // Add to cache
              }
              return {
                  name: asset.name ?? asset.crypto_symbol.toUpperCase(),
                  value: asset.value!,
                  percentage: (asset.value! / totalValue) * 100,
                  color: color,
              };
          })
          .sort((a, b) => b.value - a.value);

      setStableColors(currentColors); // Update the stable colors state
      setPortfolioDistribution(distribution);
  }, [assets, totalValue, stableColors]);


  // --- UseEffect for triggering chart updates (Original combined version) ---
  useEffect(() => {
    // Update charts when underlying data changes
    if (assets.length > 0 && totalValue > 0) {
        generatePortfolioData(); // Called frequently, uses stable shape scaled to current value
        updatePortfolioDistribution();
    } else {
        // Clear charts if no assets or value
        setPortfolioData([]);
        setPortfolioDistribution([]);
    }
    // generatePortfolioData and updatePortfolioDistribution are included as dependencies
    // because their definitions (via useCallback) depend on other state (timeframe, totalValue, assets, stableColors)
  }, [assets, totalValue, generatePortfolioData, updatePortfolioDistribution]);


  // --- Event Handlers ---
  const handleAddAsset = async () => {
    if (!user) return;
    const amountNum = parseFloat(newAsset.amount);
    const priceNum = parseFloat(newAsset.price);

    if (!newAsset.symbol || isNaN(amountNum) || amountNum <= 0 || isNaN(priceNum) || priceNum <= 0) {
      alert('Please select a coin and enter valid positive amount and price.');
      return;
    }
    setActionLoading(true);
    try {
        const { error } = await supabase.from('portfolio_assets').insert([
            {
                user_id: user.id,
                crypto_symbol: newAsset.symbol.toLowerCase(), // Store consistently
                amount: amountNum,
                avg_buy_price: priceNum,
            },
        ]);
        if (error) throw error;

        // Refetch assets to update UI
        const rawAssets = await fetchPortfolioAssets();
        if (rawAssets !== null) {
             setAssets(enrichAssets(rawAssets, availableCoins)); // Re-enrich immediately
        }

        setShowAddModal(false);
        setNewAsset({ symbol: '', amount: '', price: '', name: '' });
        setSearchQuery('');
        alert('Asset added!');
    } catch (error: any) {
      console.error('Error adding asset:', error);
      alert(`Error adding asset: ${error.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleOpenEditModal = (assetToEdit: PortfolioAsset) => {
      setEditingAsset(assetToEdit);
      setEditFormData({
          amount: assetToEdit.amount.toString(),
          price: assetToEdit.avg_buy_price.toString(),
      });
      setShowEditModal(true);
  };

  const handleCloseEditModal = () => {
      setShowEditModal(false);
      setEditingAsset(null);
      setEditFormData({ amount: '', price: '' });
  };

  const handleEditFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setEditFormData({
          ...editFormData,
          [e.target.name]: e.target.value,
      });
  };

  const handleUpdateAsset = async () => {
    if (!editingAsset || !user) return;
    const amountNum = parseFloat(editFormData.amount);
    const priceNum = parseFloat(editFormData.price);

    if (isNaN(amountNum) || amountNum < 0 || isNaN(priceNum) || priceNum < 0) { // Allow zero amount/price for selling all maybe? Adjust validation as needed.
      alert('Please enter a valid amount and price.');
      return;
    }
    setActionLoading(true);
    try {
        // TODO: Implement logic to REMOVE asset if amount becomes 0? Or handle via separate delete button.
        const { error } = await supabase
            .from('portfolio_assets')
            .update({
                amount: amountNum,
                avg_buy_price: priceNum, // Note: Updating average buy price might need more complex logic if only adding/removing partial amounts
            })
            .eq('id', editingAsset.id)
            .eq('user_id', user.id); // Security check

        if (error) throw error;

        // Refetch assets after update
        const rawAssets = await fetchPortfolioAssets();
         if (rawAssets !== null) {
             setAssets(enrichAssets(rawAssets, availableCoins)); // Re-enrich immediately
         }

        handleCloseEditModal();
        alert('Asset updated!');
    } catch (error: any) {
      console.error('Error updating asset:', error);
       alert(`Error updating asset: ${error.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const filteredCoins = useMemo(() => {
      if (!searchQuery) return [];
      const lowerCaseQuery = searchQuery.toLowerCase();
      return availableCoins.filter(coin =>
          coin.name.toLowerCase().includes(lowerCaseQuery) ||
          coin.symbol.toLowerCase().includes(lowerCaseQuery)
      );
  }, [searchQuery, availableCoins]);

  // --- Render Logic ---
  if (initialLoading && !user) return <div className="min-h-screen bg-gray-50 flex items-center justify-center">Loading user...</div>;
  if (initialLoading) return ( <div className="min-h-screen bg-gray-50 flex items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mr-3"></div><span>Loading Portfolio Data...</span></div> );

  // --- FULL JSX STRUCTURE ---
  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Portfolio Overview Stats - FULL JSX (Unchanged) */}
        <div className="mb-8">
           <h1 className="text-3xl font-bold text-gray-900 mb-6">Portfolio Overview</h1>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                <div className="bg-white overflow-hidden shadow rounded-lg p-5 flex items-center space-x-4"> <div className="rounded-md bg-indigo-100 p-3 text-indigo-600"><Wallet size={24}/></div> <div><dt className="text-sm font-medium text-gray-500 truncate">Total Value</dt><dd className="mt-1 text-2xl font-semibold text-gray-900">${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</dd></div></div>
                <div className="bg-white overflow-hidden shadow rounded-lg p-5 flex items-center space-x-4"> <div className={`rounded-md p-3 ${totalProfitLoss >= 0 ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}><DollarSign size={24}/></div> <div><dt className="text-sm font-medium text-gray-500 truncate">Total Profit/Loss</dt><dd className={`mt-1 text-2xl font-semibold ${totalProfitLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>{totalProfitLoss >= 0 ? '+' : ''}${totalProfitLoss.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</dd></div></div>
                <div className="bg-white overflow-hidden shadow rounded-lg p-5 flex items-center space-x-4"> <div className={`rounded-md p-3 ${totalProfitLoss >= 0 ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>{totalProfitLoss >= 0 ? <TrendingUp size={24} /> : <TrendingDown size={24}/>}</div> <div><dt className="text-sm font-medium text-gray-500 truncate">Total P/L %</dt><dd className={`mt-1 text-2xl font-semibold ${totalProfitLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>{totalCostBasis !== 0 ? ((totalProfitLoss / totalCostBasis) * 100).toFixed(2) : '0.00'}%</dd></div></div>
                <div className="bg-white overflow-hidden shadow rounded-lg p-5 flex items-center space-x-4"> <div className="rounded-md bg-blue-100 p-3 text-blue-600"><IconPie size={24}/></div> <div><dt className="text-sm font-medium text-gray-500 truncate">Assets Held</dt><dd className="mt-1 text-2xl font-semibold text-gray-900">{assets.length}</dd></div></div>
           </div>
        </div>

        {/* --- Portfolio Performance Chart - Animation Enabled --- */}
        <div className="bg-white p-6 rounded-lg shadow mb-8">
          <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
              <h2 className="text-xl font-semibold text-gray-900">Portfolio Performance</h2>
              <div className="flex space-x-1 sm:space-x-2">
                  {['1D', '1W', '1M'].map((tf) => (
                      <button key={tf} onClick={() => setChartTimeframe(tf)} className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${ chartTimeframe === tf ? 'bg-indigo-600 text-white shadow-sm' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' }`}>{tf}</button>
                  ))}
               </div>
            </div>
          <div className="h-96">
             {portfolioData.length > 1 ? (
                <ResponsiveContainer width="100%" height="100%">
                   {/* *** MODIFICATION: Removed isAnimationActive={false} *** */}
                   <AreaChart data={portfolioData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }} >
                       <defs><linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#4f46e5" stopOpacity={0.6}/><stop offset="95%" stopColor="#4f46e5" stopOpacity={0.1}/></linearGradient></defs>
                       <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb"/>
                       <XAxis dataKey="timestamp" tickFormatter={(ts) => new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false}/>
                       <YAxis tickFormatter={(v) => `$${v.toLocaleString()}`} stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} domain={['auto', 'auto']} width={60} />
                       <Tooltip content={({ active, payload, label }) => { if (active && payload && payload.length) { const date = new Date(label); const fmtDate = chartTimeframe === '1D' ? date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : date.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }); return (<div className="bg-white p-2 rounded shadow border text-sm"><p className="text-gray-500 mb-1">{fmtDate}</p><p className="font-semibold text-indigo-600">{`Value: $${payload[0].value?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</p></div> ); } return null; }}/>
                       {/* *** MODIFICATION: Removed isAnimationActive={false} *** */}
                       <Area type="monotone" dataKey="value" stroke="#4f46e5" fill="url(#chartGradient)" strokeWidth={2} dot={false} name="Portfolio Value" />
                   </AreaChart>
                </ResponsiveContainer>
             ) : (
                 <div className="h-full flex items-center justify-center text-gray-500 italic">Not enough data to display performance chart.</div>
              )}
          </div>
        </div>

        {/* Distribution and Performance Grid - FULL JSX (Unchanged) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Asset Distribution Pie Chart */}
            <div className="lg:col-span-1 bg-white p-6 rounded-lg shadow">
                 <h3 className="text-lg font-medium text-gray-900 mb-6">Asset Distribution</h3>
                 <div className="h-64">
                     {portfolioDistribution.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                             <RePieChart>
                                 <Tooltip content={({ active, payload }) => { if (active && payload && payload.length) { const d = payload[0].payload; return (<div className="bg-white p-2 rounded shadow border text-sm"><p className="font-medium text-gray-900">{d.name}</p><p className="text-xs text-gray-600">Value: ${d.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p><p className="text-xs font-semibold" style={{color: d.color}}>{d.percentage.toFixed(1)}%</p></div>); } return null; }}/>
                                  <Pie data={portfolioDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={2} label={false}>
                                      {portfolioDistribution.map((e, i) => ( <Cell key={`cell-${i}`} fill={e.color} stroke={"#FFF"} strokeWidth={1}/> ))}
                                  </Pie>
                             </RePieChart>
                         </ResponsiveContainer>
                      ) : (
                         <div className="h-full flex items-center justify-center text-gray-500 italic">No assets to display distribution.</div>
                      )}
                 </div>
                 <div className="mt-6 space-y-2 max-h-40 overflow-y-auto pr-2">
                     {portfolioDistribution.map((a, i) => ( <div key={i} className="flex items-center justify-between text-sm"><div className="flex items-center truncate"><div className="w-3 h-3 rounded-full mr-2 shrink-0" style={{ backgroundColor: a.color }}/> <span className="text-gray-700 truncate">{a.name}</span> </div><div className="text-gray-900 font-medium shrink-0 pl-2">{a.percentage.toFixed(1)}%</div></div> ))}
                 </div>
            </div>
            {/* Asset Performance List */}
            <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow">
               <h3 className="text-lg font-medium text-gray-900 mb-4">Asset Performance</h3>
               <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                  {assets.length > 0 ? assets.map((a) => ( <div key={a.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:shadow-md transition-shadow duration-200"><div className="flex items-center space-x-3"><img src={a.logo} alt={a.name} className="w-8 h-8 rounded-full shrink-0" /><div className="truncate"><p className="font-medium text-gray-900 truncate">{a.name}</p><p className="text-sm text-gray-500">{a.amount.toLocaleString(undefined, {maximumFractionDigits: 8})} {a.crypto_symbol.toUpperCase()}</p></div></div><div className="text-right shrink-0 pl-2"><p className="font-medium text-gray-900">${a.value?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p><p className={`text-sm ${a.profit_loss_percentage != null && a.profit_loss_percentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>{a.profit_loss_percentage != null && a.profit_loss_percentage >= 0 ? '+' : ''}{a.profit_loss_percentage?.toFixed(2) ?? '0.00'}%</p></div></div> )) : ( <p className="text-center text-gray-500 py-4 italic">Your portfolio is empty.</p> )}
                </div>
            </div>
        </div>

        {/* Full Assets Table - FULL JSX (Unchanged) */}
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6 flex justify-between items-center flex-wrap gap-2"> <h3 className="text-xl leading-6 font-semibold text-gray-900">Your Holdings</h3> <button onClick={() => { setNewAsset({ symbol: '', amount: '', price: '', name: '' }); setSearchQuery(''); setIsDropdownVisible(false); setShowAddModal(true); }} className="bg-indigo-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"> Add New Asset </button> </div>
            <div className="border-t border-gray-200 overflow-x-auto"> <table className="min-w-full divide-y divide-gray-200"> <thead className="bg-gray-50"><tr> <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Asset</th> <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Holdings</th> <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Avg Buy Price</th> <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Current Price</th> <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th> <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Profit/Loss</th> <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">P/L %</th> <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th> </tr></thead> <tbody className="bg-white divide-y divide-gray-200"> {assets.length > 0 ? assets.map((a) => ( <tr key={a.id} className="hover:bg-gray-50"> <td className="px-6 py-4 whitespace-nowrap"><div className="flex items-center"><div className="shrink-0 h-8 w-8"><img className="h-8 w-8 rounded-full" src={a.logo} alt="" /></div><div className="ml-3"><div className="text-sm font-medium text-gray-900">{a.name}</div><div className="text-sm text-gray-500">{a.crypto_symbol.toUpperCase()}</div></div></div></td> <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{a.amount.toLocaleString(undefined, { maximumFractionDigits: 8 })}</td> <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">${a.avg_buy_price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td> <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">${a.current_price?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td> <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-right">${a.value?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td> <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium text-right ${a.profit_loss != null && a.profit_loss >= 0 ? 'text-green-600' : 'text-red-600'}`}>{a.profit_loss != null && a.profit_loss >= 0 ? '+' : ''}${a.profit_loss?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td> <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium text-right ${a.profit_loss_percentage != null && a.profit_loss_percentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>{a.profit_loss_percentage != null && a.profit_loss_percentage >= 0 ? '+' : ''}{a.profit_loss_percentage?.toFixed(2)}%</td> <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium"><button onClick={() => handleOpenEditModal(a)} className="text-indigo-600 hover:text-indigo-900" title="Edit Asset"><Edit className="h-4 w-4" /></button></td> </tr> )) : ( <tr><td colSpan={8} className="px-6 py-4 text-center text-gray-500 italic">No assets in your portfolio yet.</td></tr> )} </tbody> </table> </div>
        </div>

        {/* --- Add Asset Modal --- */}
        {showAddModal && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 transition-opacity duration-300 ease-out" aria-labelledby="modal-title" role="dialog" aria-modal="true">
            <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4 shadow-xl transform transition-all duration-300 ease-out scale-95 opacity-0 animate-fade-in-scale">
                <div className="flex justify-between items-center mb-4">
                     <h3 className="text-lg font-medium text-gray-900" id="modal-title">Add New Asset</h3>
                     <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600">
                         <X size={20} />
                     </button>
                </div>
              <div className="space-y-4">
                {/* Search Input and Dropdown */}
                <div className="relative">
                   <label htmlFor="search-crypto-add" className="block text-sm font-medium text-gray-700 mb-1">Cryptocurrency</label>
                  <input
                    id="search-crypto-add" type="text" value={searchQuery}
                    onChange={(e) => { setSearchQuery(e.target.value); setIsDropdownVisible(true); }}
                    onFocus={() => setIsDropdownVisible(true)}
                    onBlur={() => setTimeout(() => setIsDropdownVisible(false), 150)} // Delay allows click on dropdown
                    placeholder="Search by name or symbol..."
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" autoComplete="off"
                  />
                  {isDropdownVisible && filteredCoins.length > 0 && (
                    <div className="absolute z-20 w-full mt-1 bg-white rounded-md shadow-lg max-h-60 overflow-auto border border-gray-200">
                      {filteredCoins.map(coin => (
                        <div
                          key={coin.id}
                          className="flex items-center p-3 hover:bg-gray-100 cursor-pointer"
                          onMouseDown={(e) => e.preventDefault()} // Prevent blur before click
                          onClick={() => {
                            setNewAsset({
                              symbol: coin.symbol.toUpperCase(), amount: '',
                              price: coin.current_price?.toString() ?? '', // Pre-fill current price
                              name: coin.name
                            });
                            setSearchQuery(coin.name);
                            setIsDropdownVisible(false);
                          }}
                        >
                          <img src={coin.image} alt="" className="w-6 h-6 rounded-full mr-3 shrink-0" />
                          <div className="flex-grow truncate"><div className="text-sm font-medium text-gray-900 truncate">{coin.name}</div><div className="text-sm text-gray-500">{coin.symbol.toUpperCase()}</div></div>
                          <div className="ml-auto text-sm text-gray-600 shrink-0 pl-2">${coin.current_price?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                 {/* Selected Asset Display */}
                 {newAsset.symbol && !isDropdownVisible && ( <div className="p-2 bg-indigo-50 border border-indigo-100 rounded-md"><span className="text-sm font-medium text-indigo-700">Selected: {newAsset.name} ({newAsset.symbol})</span></div> )}
                {/* Amount Input */}
                <div>
                  <label htmlFor="amount-add" className="block text-sm font-medium text-gray-700">Amount</label>
                  <input id="amount-add" type="number" value={newAsset.amount} onChange={(e) => setNewAsset({ ...newAsset, amount: e.target.value })} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder="e.g., 0.5" step="any" min="0"/>
                </div>
                {/* Average Buy Price Input */}
                <div>
                  <label htmlFor="buy-price-add" className="block text-sm font-medium text-gray-700">Average Buy Price (per coin in $)</label>
                  <input id="buy-price-add" type="number" value={newAsset.price} onChange={(e) => setNewAsset({ ...newAsset, price: e.target.value })} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder="e.g., 40000.00" step="any" min="0"/>
                   {newAsset.symbol && ( <p className="mt-1 text-xs text-gray-500">Current market price: ~${availableCoins.find(c => c.symbol.toUpperCase() === newAsset.symbol)?.current_price?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 'N/A'}</p> )}
                </div>
                {/* Modal Buttons */}
                <div className="flex justify-end space-x-3 pt-4">
                  <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 rounded-md border border-gray-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cancel</button>
                  <button type="button" onClick={handleAddAsset} disabled={actionLoading} className={`inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${actionLoading ? 'opacity-50 cursor-not-allowed' : ''}`}> {actionLoading ? (<><svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Adding...</>) : 'Add Asset'} </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* --- Edit Asset Modal --- */}
        {showEditModal && editingAsset && (
           <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 transition-opacity duration-300 ease-out" aria-labelledby="edit-modal-title" role="dialog" aria-modal="true">
             <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4 shadow-xl transform transition-all duration-300 ease-out scale-95 opacity-0 animate-fade-in-scale">
                 <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-medium text-gray-900" id="edit-modal-title">Edit {editingAsset.name} ({editingAsset.crypto_symbol.toUpperCase()})</h3>
                      <button onClick={handleCloseEditModal} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
                 </div>
               <div className="space-y-4">
                 {/* Amount Input */}
                 <div>
                   <label htmlFor="amount-edit" className="block text-sm font-medium text-gray-700">Amount</label>
                   <input id="amount-edit" type="number" name="amount" value={editFormData.amount} onChange={handleEditFormChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder="e.g., 0.5" step="any" min="0"/>
                 </div>
                 {/* Average Buy Price Input */}
                 <div>
                   <label htmlFor="buy-price-edit" className="block text-sm font-medium text-gray-700">Average Buy Price (per coin in $)</label>
                   <input id="buy-price-edit" type="number" name="price" value={editFormData.price} onChange={handleEditFormChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder="e.g., 40000.00" step="any" min="0"/>
                     <p className="mt-1 text-xs text-gray-500">Current market price: ~${editingAsset.current_price?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 'N/A'}</p>
                 </div>
                 {/* Modal Buttons */}
                 <div className="flex justify-end space-x-3 pt-4">
                   <button type="button" onClick={handleCloseEditModal} className="px-4 py-2 text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 rounded-md border border-gray-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cancel</button>
                   <button type="button" onClick={handleUpdateAsset} disabled={actionLoading} className={`inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${actionLoading ? 'opacity-50 cursor-not-allowed' : ''}`}> {actionLoading ? (<><svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Updating...</>) : 'Update Asset'} </button>
                 </div>
               </div>
             </div>
           </div>
        )}

      </div>
      {/* Ensure animation style is present */}
      <style>{` @keyframes fadeInScale { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } } .animate-fade-in-scale { animation: fadeInScale 0.2s ease-out forwards; } `}</style>
    </div>
  );
}
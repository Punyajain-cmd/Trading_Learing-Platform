import React, { useState } from 'react';
import { getCryptoPrices, CryptoPrice } from '../lib/api';
import { ArrowRight } from 'lucide-react';

const COIN_CATEGORIES: { [key: string]: string[] } = {
  'DeFi': [
    'uni', 'aave', 'cake', 'comp', 'mkr', 'crv', 'sushi', '1inch', 'snx', 'yfi',
    'ldo', 'dydx', 'rune', 'bal', 'kava', 'inj', 'qnt', 'ren', 'bnt', 'alpha'
  ],
  'Smart Contract Platforms': [
    'eth', 'bnb', 'sol', 'ada', 'avax', 'dot', 'near', 'atom', 'algo', 'ftm',
    'matic', 'trx', 'etc', 'one', 'egld', 'icp', 'xdc', 'kas', 'zil', 'neo'
  ],
  'GameFi': [
    'sand', 'mana', 'axs', 'gala', 'ilv', 'enjin', 'ultra', 'gods', 'mc', 'alice',
    'tlm', 'hero', 'ygg', 'star', 'magic', 'iog', 'atlas', 'polis', 'slp', 'dep'
  ],
  'Scaling Solutions': [
    'matic', 'op', 'arb', 'imx', 'omg', 'zks', 'metis', 'boba', 'celr', 'zk',
    'skl', 'rlc', 'strk', 'rose', 'sys', 'ctsi', 'mina', 'celo', 'xdai', 'iotx'
  ],
  'NFTs & Digital Collectibles': [
    'ape', 'flow', 'chz', 'enj', 'rare', 'theta', 'audio', 'looks', 'super', 'pla',
    'ogn', 'anc', 'gmt', 'waxp', 'rndr', 'mov', 'alice', 'tvk', 'ghst', 'nft'
  ],
  'Web3 Infrastructure': [
    'link', 'grt', 'fil', 'ar', 'ocean', 'api3', 'band', 'rndr', 'storj', 'glm',
    'ankr', 'flux', 'ach', 'keep', 'nkn', 'lpt', 'poly', 'rlc', 'nu', 'dia'
  ]
};

const CATEGORY_IMAGES: { [key: string]: string } = {
  'DeFi': 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=600&h=300',
  'Smart Contract Platforms': 'https://images.unsplash.com/photo-1639322537228-f710d846310a?auto=format&fit=crop&w=600&h=300',
  'GameFi': 'https://images.unsplash.com/photo-1640158615573-cd28feb1bf4e?auto=format&fit=crop&w=600&h=300',
  'Scaling Solutions': 'https://images.unsplash.com/photo-1642104704074-907c0698cbd9?auto=format&fit=crop&w=600&h=300',
  'NFTs & Digital Collectibles': 'https://images.unsplash.com/photo-1620321023374-d1a68fbc720d?auto=format&fit=crop&w=600&h=300',
  'Web3 Infrastructure': 'https://images.unsplash.com/photo-1642104704074-907c0698cbd9?auto=format&fit=crop&w=600&h=300'
};

export default function CryptoCategoriesPage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categoryCoins, setCategoryCoins] = useState<CryptoPrice[]>([]);
  const [loading, setLoading] = useState(false);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const handleViewCategory = async (category: string) => {
    if (expandedCategory === category) {
      setExpandedCategory(null);
      return;
    }
    
    setExpandedCategory(category);
    setLoading(true);
    try {
      const allCoins = await getCryptoPrices();
      const categorySymbols = COIN_CATEGORIES[category];
      const filteredCoins = allCoins.filter(coin => 
        categorySymbols.includes(coin.symbol.toLowerCase())
      );
      setCategoryCoins(filteredCoins);
    } catch (error) {
      console.error('Error fetching category coins:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">Cryptocurrency Categories</h1>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {Object.entries(COIN_CATEGORIES).map(([category, coins]) => (
            <React.Fragment key={category}>
              <div className="bg-white overflow-hidden shadow rounded-lg hover:shadow-lg transition-shadow">
                <div className="relative h-48">
                  <img
                    src={CATEGORY_IMAGES[category]}
                    alt={category}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3 className="text-xl font-semibold text-white mb-2">{category}</h3>
                    <p className="text-sm text-gray-200">
                      {coins.length} coins
                    </p>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex flex-wrap gap-2 mb-4">
                    {coins.slice(0, 5).map(symbol => (
                      <span key={symbol} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                        {symbol.toUpperCase()}
                      </span>
                    ))}
                    {coins.length > 5 && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                        +{coins.length - 5} more
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => handleViewCategory(category)}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 w-full justify-center"
                  >
                    {expandedCategory === category ? 'Hide Details' : 'View Category'}
                    <ArrowRight className={`ml-2 h-4 w-4 transition-transform duration-200 ${
                      expandedCategory === category ? 'rotate-90' : ''
                    }`} />
                  </button>
                </div>
              </div>
              
              {/* Expanded Category View */}
              {expandedCategory === category && (
                <div className="col-span-full bg-white shadow-lg rounded-lg overflow-hidden mt-4 mb-8">
                  {loading ? (
                    <div className="flex justify-center items-center h-64">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Name
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Price
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              24h Change
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Market Cap
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Volume(24h)
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {categoryCoins.map((coin) => (
                            <tr key={coin.id} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                  <div className="flex-shrink-0 h-10 w-10">
                                    <img className="h-10 w-10 rounded-full" src={coin.image} alt={coin.name} />
                                  </div>
                                  <div className="ml-4">
                                    <div className="text-sm font-medium text-gray-900">{coin.name}</div>
                                    <div className="text-sm text-gray-500">{coin.symbol.toUpperCase()}</div>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                ${coin.current_price.toLocaleString()}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                  coin.price_change_percentage_24h >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                }`}>
                                  {coin.price_change_percentage_24h >= 0 ? '+' : ''}{coin.price_change_percentage_24h.toFixed(2)}%
                                </span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                ${coin.market_cap.toLocaleString()}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                ${coin.total_volume.toLocaleString()}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Shield, Target, Award, IndianRupee, Users, TrendingUp, Gift, Trophy, ArrowRight } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="bg-gray-50">
      {/* Hero Section with Parallax Effect */}
      <div className="relative overflow-hidden bg-indigo-900 text-white py-20">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1642790551116-18e150f248e3?auto=format&fit=crop&w=2000&q=80"
            alt="Trading Background"
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold mb-4 animate-fade-in">
            Your Gateway to Trading Success
          </h2>
          <p className="text-xl text-indigo-200 max-w-2xl mx-auto animate-fade-in" style={{animationDelay: '0.2s'}}>
            We're dedicated to making trading education accessible, practical, and risk-free for everyone.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:py-24 lg:px-8">
        {/* How it Works Flow Map */}
        <div className="mt-20">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-12">Your Journey to Trading Success</h3>
          <div className="relative">
            {/* Flow Steps */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  icon: <Gift className="h-6 w-6 text-white" />,
                  title: "1. Get Started",
                  description: "Sign up and receive ₹10 Lakh in virtual money instantly",
                  image: "https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?auto=format&fit=crop&w=300&h=200&q=80"
                },
                {
                  icon: <TrendingUp className="h-6 w-6 text-white" />,
                  title: "2. Learn & Practice",
                  description: "Access comprehensive tutorials and practice risk-free",
                  image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=300&h=200&q=80"
                },
                {
                  icon: <IndianRupee className="h-6 w-6 text-white" />,
                  title: "3. Start Small",
                  description: "Begin real trading with just ₹49",
                  image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&w=300&h=200&q=80"
                },
                {
                  icon: <Trophy className="h-6 w-6 text-white" />,
                  title: "4. Compete & Win",
                  description: "Join competitions with chance to win up to ₹10 Lakh",
                  image: "https://images.unsplash.com/photo-1579226905180-636b76d96082?auto=format&fit=crop&w=300&h=200&q=80"
                }
              ].map((step, index) => (
                <div key={index} className="relative bg-white rounded-lg shadow-md overflow-hidden group hover:shadow-xl transition-shadow duration-300">
                  <div className="h-40 overflow-hidden">
                    <img
                      src={step.image}
                      alt={step.title}
                      className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  <div className="absolute top-32 left-1/2 transform -translate-x-1/2">
                    <div className="bg-indigo-600 rounded-full p-3 shadow-lg animate-float">
                      {step.icon}
                    </div>
                  </div>
                  <div className="pt-12 p-6 text-center">
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">{step.title}</h4>
                    <p className="text-gray-500">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Connecting Lines */}
            <div className="hidden lg:block absolute top-[45%] left-0 right-0 h-0.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
          </div>
        </div>

        {/* Key Features with Hover Effects */}
        <div className="mt-32">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-12">Key Features</h3>
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
            {[
              {
                icon: <Shield className="h-6 w-6" />,
                title: "Safe Learning Environment",
                description: "Practice trading without risking real money. Start with ₹10 Lakh virtual money.",
                image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=400&h=300&q=80"
              },
              {
                icon: <Users className="h-6 w-6" />,
                title: "Real Market Experience",
                description: "Trade alongside real players in live market conditions.",
                image: "https://images.unsplash.com/photo-1591696205602-2f950c417cb9?auto=format&fit=crop&w=400&h=300&q=80"
              },
              {
                icon: <Award className="h-6 w-6" />,
                title: "Weekly Competitions",
                description: "Join weekly leaderboards with real cash prizes up to ₹10 Lakh.",
                image: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=400&h=300&q=80"
              }
            ].map((feature, index) => (
              <div key={index} className="relative group">
                <div className="relative h-48 mb-6 rounded-lg overflow-hidden">
                  <img
                    src={feature.image}
                    alt={feature.title}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/80 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <div className="flex items-center space-x-2">
                      <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                        {feature.icon}
                      </div>
                      <h3 className="text-lg font-medium">{feature.title}</h3>
                    </div>
                  </div>
                </div>
                <p className="text-base text-gray-500">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Animated Welcome Bonus Section */}
        <div className="mt-32">
          <div className="relative bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-8 overflow-hidden">
            <div className="absolute inset-0">
              <div className="absolute inset-0 bg-black opacity-10"></div>
              <div className="absolute -right-20 -top-20 w-64 h-64 bg-white/20 rounded-full blur-3xl"></div>
              <div className="absolute -left-20 -bottom-20 w-64 h-64 bg-white/20 rounded-full blur-3xl"></div>
            </div>
            <div className="relative text-center text-white">
              <Gift className="h-16 w-16 text-white/90 mx-auto mb-6 animate-float" />
              <h3 className="text-3xl font-bold mb-4">Welcome Bonus</h3>
              <p className="text-2xl text-white/90 mb-2">
                Start your journey with ₹10 Lakh in virtual trading money!
              </p>
              <p className="text-lg text-white/80">
                Begin real trading with just ₹49 and compete for weekly prizes
              </p>
            </div>
          </div>
        </div>

        {/* Getting Started Steps with Animation */}
        <div className="mt-32">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">How to Get Started</h3>
          <div className="bg-white shadow-lg rounded-lg overflow-hidden">
            <div className="px-6 py-8">
              <ol className="space-y-6">
                {[
                  "Sign up for a free account and get ₹10 Lakh virtual money",
                  "Practice trading with virtual money in real market conditions",
                  "Start real trading with just ₹9",
                  "Join weekly competitions and leaderboards",
                  "Win real cash prizes up to ₹10 Lakh"
                ].map((step, index) => (
                  <li key={index} className="flex items-center space-x-4 group">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center group-hover:bg-indigo-600 transition-colors duration-300">
                      <span className="text-indigo-600 font-semibold group-hover:text-white transition-colors duration-300">
                        {index + 1}
                      </span>
                    </div>
                    <span className="text-gray-600 group-hover:text-indigo-600 transition-colors duration-300">
                      {step}
                    </span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
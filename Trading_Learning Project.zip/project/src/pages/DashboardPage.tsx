import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Camera, Save, Award, Calendar, AlertCircle } from 'lucide-react';

interface UserProfile {
  username: string;
  real_name?: string;
  date_of_birth?: string;
  game_money: number;
  bio?: string;
  avatar_url?: string;
  trading_style?: string;
  experience_level?: string;
  favorite_markets?: string;
  banner_url?: string;
}

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState<UserProfile | null>(null);
  const [participatedEvents, setParticipatedEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [saveLoading, setSaveLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' }>({ text: '', type: 'success' });
  const [currentEvents, setCurrentEvents] = useState([]);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [bannerUrl, setBannerUrl] = useState<string | null>(null);
  const [bannerFile, setBannerFile] = useState<File | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    fetchUserProfile();
    fetchParticipatedEvents();
    fetchCurrentEvents();
  }, [user]);

  async function fetchCurrentEvents() {
    try {
      setFetchError(null);
      const { data, error } = await supabase
        .from('event_participants')
        .select(`
          *,
          trading_events (*)
        `)
        .eq('user_id', user!.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching current events:', error);
        setFetchError('Unable to load current events. Please try again later.');
        return;
      }

      setCurrentEvents(data || []);
    } catch (error) {
      console.error('Error fetching current events:', error);
      setFetchError('An unexpected error occurred. Please try again later.');
    }
  }

  async function fetchUserProfile() {
    try {
      setFetchError(null);
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', user!.id)
        .single();

      if (error) {
        console.error('Error fetching profile:', error);
        setFetchError('Unable to load profile data. Please try again later.');
        return;
      }

      setProfile(data);
      setBannerUrl(data.banner_url || 'https://images.unsplash.com/photo-1642790551116-18e150f248e3?auto=format&fit=crop&w=2000&q=80');
      setEditedProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
      setFetchError('An unexpected error occurred while loading your profile.');
    } finally {
      setLoading(false);
    }
  }

  async function fetchParticipatedEvents() {
    try {
      const { data, error } = await supabase
        .from('event_participants')
        .select(`
          *,
          trading_events (*)
        `)
        .eq('user_id', user?.id);

      if (error) throw error;
      setParticipatedEvents(data);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  }

  async function updateProfile() {
    try {
      setSaveLoading(true);
      let avatarUrl = profile?.avatar_url;
      let updatedBannerUrl = bannerUrl;

      if (avatarFile) {
        const fileExt = avatarFile.name.split('.').pop();
        const fileName = `${user?.id}/avatar.${fileExt}`;

        // First, delete existing avatar if it exists
        if (profile?.avatar_url) {
          const oldFileName = profile.avatar_url.split('/').pop();
          if (oldFileName) {
            await supabase.storage
              .from('avatars')
              .remove([`${user?.id}/${oldFileName}`]);
          }
        }

        // Upload new avatar
        const { error: uploadError, data } = await supabase.storage
          .from('avatars')
          .upload(fileName, avatarFile, {
            cacheControl: '0',
            upsert: true
          });

        if (uploadError) throw uploadError;

        // Get the public URL
        const { data: { publicUrl } } = supabase.storage
          .from('avatars')
          .getPublicUrl(fileName);

        avatarUrl = publicUrl;
      }

      if (bannerFile) {
        const fileExt = bannerFile.name.split('.').pop();
        const bannerPath = `${user?.id}/banner.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('avatars')
          .upload(bannerPath, bannerFile, {
            cacheControl: '0',
            upsert: true
          });

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('avatars')
          .getPublicUrl(bannerPath);

        updatedBannerUrl = publicUrl;
      }

      // Update the profile with all changes including the new avatar URL
      const { error: updateError } = await supabase
        .from('users')
        .update({
          real_name: editedProfile?.real_name,
          date_of_birth: editedProfile?.date_of_birth,
          bio: editedProfile?.bio,
          trading_style: editedProfile?.trading_style,
          experience_level: editedProfile?.experience_level,
          favorite_markets: editedProfile?.favorite_markets,
          avatar_url: avatarUrl,
          banner_url: updatedBannerUrl,
        })
        .eq('id', user?.id);

      if (updateError) throw updateError;

      // Update local state with the new profile data
      const updatedProfile = { 
        ...editedProfile!, 
        avatar_url: avatarUrl,
        banner_url: updatedBannerUrl
      };
      setProfile(updatedProfile);
      setEditedProfile(updatedProfile);
      setIsEditing(false);
      setAvatarFile(null);
      setBannerFile(null);
      setBannerUrl(updatedBannerUrl);
      setMessage({ text: 'Profile updated successfully', type: 'success' });
      
      // Clear success message after 3 seconds
      setTimeout(() => setMessage({ text: '', type: 'success' }), 3000);
    } catch (error) {
      console.error('Error updating profile:', error);
      setMessage({ text: 'Failed to update profile. Please try again.', type: 'error' });
    } finally {
      setSaveLoading(false);
    }
  }

  function handleAvatarChange(event: React.ChangeEvent<HTMLInputElement>) {
    if (!event.target.files || !event.target.files[0]) return;
    
    const file = event.target.files[0];
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      setMessage({ text: 'Please select an image file', type: 'error' });
      return;
    }
    
    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setMessage({ text: 'Image size should be less than 5MB', type: 'error' });
      return;
    }
    
    setAvatarFile(file);

    // Create a preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setEditedProfile(prev => prev ? { ...prev, avatar_url: reader.result as string } : null);
    };
    reader.readAsDataURL(file);
  }

  function handleBannerChange(event: React.ChangeEvent<HTMLInputElement>) {
    if (!event.target.files || !event.target.files[0]) return;
    
    const file = event.target.files[0];
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      setMessage({ text: 'Please select an image file', type: 'error' });
      return;
    }
    
    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setMessage({ text: 'Image size should be less than 5MB', type: 'error' });
      return;
    }
    
    setBannerFile(file);

    // Create a preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setBannerUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Error/Success Message */}
        {message.text && (
          <div className={`mb-4 ${
            message.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
          } border rounded-md p-4`}>
            <p className={`text-sm ${
              message.type === 'success' ? 'text-green-700' : 'text-red-700'
            }`}>{message.text}</p>
          </div>
        )}
        
        {/* Fetch Error Message */}
        {fetchError && (
          <div className="mb-8 bg-red-50 border border-red-200 rounded-md p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-red-400" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Error</h3>
                <p className="mt-2 text-sm text-red-700">{fetchError}</p>
                <button
                  onClick={() => {
                    setFetchError(null);
                    fetchUserProfile();
                    fetchCurrentEvents();
                  }}
                  className="mt-2 text-sm font-medium text-red-600 hover:text-red-500"
                >
                  Try Again
                </button>
              </div>
            </div>
          </div>
        )}
        <div className="bg-white shadow rounded-lg">
          {/* Profile Header */}
          <div className="relative h-48 rounded-t-lg overflow-hidden">
            <img
              src={bannerUrl || 'https://images.unsplash.com/photo-1642790551116-18e150f248e3?auto=format&fit=crop&w=2000&q=80'}
              alt="Profile Banner"
              className="w-full h-full object-cover"
            />
            {isEditing && (
              <label className="absolute top-4 right-4 bg-white rounded-full p-2 cursor-pointer shadow-lg hover:bg-gray-100 transition-colors">
                <Camera className="h-5 w-5 text-gray-600" />
                <input
                  type="file"
                  className="hidden"
                  accept="image/*"
                  onChange={handleBannerChange}
                />
              </label>
            )}
            <div className="absolute -bottom-16 left-8">
              <div className="relative">
                <img
                  src={editedProfile?.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=faces'}
                  alt="Profile"
                  className="w-40 h-40 rounded-full border-4 border-white object-cover shadow-lg bg-white flex-shrink-0"
                  style={{ objectFit: 'cover' }}
                />
                {isEditing && (
                  <label className="absolute bottom-3 right-3 bg-white rounded-full p-2.5 cursor-pointer shadow-lg hover:bg-gray-100 transition-colors">
                    <Camera className="h-4 w-4 text-gray-600" />
                    <input
                      type="file"
                      className="hidden"
                      accept="image/*"
                      onChange={handleAvatarChange}
                    />
                  </label>
                )}
              </div>
              <div className="mt-4 text-center">
                <h2 className="text-xl font-bold text-gray-900">{profile?.username}</h2>
                <p className="text-sm text-gray-600">Member since {new Date().toLocaleDateString()}</p>
              </div>
            </div>
          </div>

          {/* Profile Info */}
          <div className="px-8 pt-24 pb-8">
            <div className="flex justify-between items-start mb-8">
              <h2 className="text-2xl font-bold text-gray-900">Profile Information</h2>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-sm text-gray-500">Game Money</p>
                  <p className="text-xl font-bold text-indigo-600">₹{profile?.game_money?.toLocaleString() || '0'}</p>
                </div>
                {isEditing ? (
                  <button
                    onClick={updateProfile}
                    disabled={saveLoading}
                    className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {saveLoading ? (
                      <span className="flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Saving...
                      </span>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Changes
                      </>
                    )}
                  </button>
                ) : (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
                  >
                    Edit Profile
                  </button>
                )}
              </div>
            </div>

            {/* Profile Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Basic Information</h3>
                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Real Name</label>
                      <input
                        type="text"
                        value={editedProfile?.real_name || ''}
                        onChange={(e) => setEditedProfile(prev => ({ ...prev!, real_name: e.target.value }))}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        placeholder="Enter your real name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Date of Birth</label>
                      <input
                        type="date"
                        value={editedProfile?.date_of_birth || ''}
                        onChange={(e) => setEditedProfile(prev => ({ ...prev!, date_of_birth: e.target.value }))}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Trading Style</label>
                      <input
                        type="text"
                        value={editedProfile?.trading_style || ''}
                        onChange={(e) => setEditedProfile(prev => ({ ...prev!, trading_style: e.target.value }))}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        placeholder="e.g., Day Trading, Swing Trading"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Experience Level</label>
                      <select
                        value={editedProfile?.experience_level || ''}
                        onChange={(e) => setEditedProfile(prev => ({ ...prev!, experience_level: e.target.value }))}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      >
                        <option value="">Select Level</option>
                        <option value="beginner">Beginner</option>
                        <option value="intermediate">Intermediate</option>
                        <option value="advanced">Advanced</option>
                      </select>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-gray-500">Real Name</p>
                      <p className="text-base">{profile?.real_name || 'Not specified'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Date of Birth</p>
                      <p className="text-base">
                        {profile?.date_of_birth ? new Date(profile.date_of_birth).toLocaleDateString() : 'Not specified'}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Trading Style</p>
                      <p className="text-base">{profile?.trading_style || 'Not specified'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Experience Level</p>
                      <p className="text-base capitalize">{profile?.experience_level || 'Not specified'}</p>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">About Me</h3>
                {isEditing ? (
                  <textarea
                    value={editedProfile?.bio || ''}
                    onChange={(e) => setEditedProfile(prev => ({ ...prev!, bio: e.target.value }))}
                    rows={4}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    placeholder="Tell us about yourself..."
                  />
                ) : (
                  <p className="text-base text-gray-700">{profile?.bio || 'No bio provided'}</p>
                )}

                <div className="mt-6">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Favorite Markets</h4>
                  {isEditing ? (
                    <input
                      type="text"
                      value={editedProfile?.favorite_markets || ''}
                      onChange={(e) => setEditedProfile(prev => ({ ...prev!, favorite_markets: e.target.value }))}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      placeholder="e.g., Forex, Crypto, Stocks"
                    />
                  ) : (
                    <p className="text-base text-gray-700">{profile?.favorite_markets || 'Not specified'}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Current Events Section */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Current Events</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {currentEvents.map((event: any) => (
                  <div key={event.id} className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-lg font-medium text-gray-900">
                        {event.trading_events.title}
                      </h4>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        event.trading_events.status === 'active' 
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {event.trading_events.status.charAt(0).toUpperCase() + event.trading_events.status.slice(1)}
                      </span>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm text-gray-500">
                        Started: {new Date(event.created_at).toLocaleDateString()}
                      </p>
                      <p className="text-sm text-gray-500">
                        Ends: {new Date(event.trading_events.end_time).toLocaleDateString()}
                      </p>
                      <div className="flex items-center justify-between mt-4">
                        <div>
                          <p className="text-sm text-gray-500">Current Balance</p>
                          <p className="text-lg font-semibold text-indigo-600">
                            ₹{event.current_balance.toLocaleString()}
                          </p>
                        </div>
                        <Link
                          to={`/live-games?event=${event.trading_events.id}`}
                          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                        >
                          Continue Trading
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
                {currentEvents.length === 0 && (
                  <div className="col-span-2 text-center py-8 bg-gray-50 rounded-lg">
                    <p className="text-gray-500">You haven't joined any events yet.</p>
                    <Link
                      to="/live-games"
                      className="inline-flex items-center px-4 py-2 mt-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                    >
                      Browse Events
                    </Link>
                  </div>
                )}
              </div>
            </div>

            {/* Recent Activity */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Recent Activity</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {participatedEvents.map((participation: any) => (
                  <div key={participation.id} className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        {participation.trading_events.status === 'completed' ? (
                          <Award className="h-6 w-6 text-indigo-600" />
                        ) : (
                          <Calendar className="h-6 w-6 text-indigo-600" />
                        )}
                      </div>
                      <div className="ml-4">
                        <h4 className="text-base font-medium text-gray-900">
                          {participation.trading_events.title}
                        </h4>
                        <p className="text-sm text-gray-500">
                          Current Balance: ${participation.current_balance.toLocaleString()}
                        </p>
                        <p className="text-sm text-gray-500">
                          Status: {participation.trading_events.status}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { getCryptoPrices, getTopGainersLosers, CryptoPrice } from '../lib/api';
import LivePriceChart from '../components/LivePriceChart';
import { Search, SortAsc, SortDesc, TrendingUp, TrendingDown, DollarSign, BarChart2, Activity, Star, ExternalLink } from 'lucide-react';
import { initializePriceWebSocket, cleanupWebSocket, priceUpdates } from '../lib/api';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate, Link } from 'react-router-dom';

export default function CryptoCoinsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [cryptocurrencies, setCryptocurrencies] = useState<CryptoPrice[]>([]);
  const [topMovers, setTopMovers] = useState<{ gainers: CryptoPrice[]; losers: CryptoPrice[] }>({ gainers: [], losers: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [watchlist, setWatchlist] = useState<string[]>([]);
  const [searchParams, setSearchParams] = useState({
    query: '',
    sortBy: 'market_cap',
    sortDirection: 'desc'
  });

  useEffect(() => {
    fetchCryptocurrencies();
    if (user) {
      fetchWatchlist();
    }
    const interval = setInterval(fetchCryptocurrencies, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, [user]);

  const fetchWatchlist = async () => {
    try {
      const { data, error } = await supabase
        .from('watchlist')
        .select('crypto_id')
        .eq('user_id', user?.id);

      if (error) throw error;
      setWatchlist(data?.map(item => item.crypto_id) || []);
    } catch (error) {
      console.error('Error fetching watchlist:', error);
    }
  };

  const toggleWatchlist = async (cryptoId: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }

    try {
      if (watchlist.includes(cryptoId)) {
        // Remove from watchlist
        const { error } = await supabase
          .from('watchlist')
          .delete()
          .eq('user_id', user.id)
          .eq('crypto_id', cryptoId);

        if (error) throw error;
        setWatchlist(prev => prev.filter(id => id !== cryptoId));
      } else {
        // Add to watchlist
        const { error } = await supabase
          .from('watchlist')
          .insert([{
            user_id: user.id,
            crypto_id: cryptoId
          }]);

        if (error) throw error;
        setWatchlist(prev => [...prev, cryptoId]);
      }
    } catch (error) {
      console.error('Error updating watchlist:', error);
    }
  };

  const fetchCryptocurrencies = async () => {
    try {
      const data = await getCryptoPrices();
      const movers = await getTopGainersLosers();
      setCryptocurrencies(data);
      setTopMovers(movers);
    } catch (error) {
      setError('Failed to fetch cryptocurrency data');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (cryptocurrencies.length > 0) {
      const symbols = cryptocurrencies.map(crypto => crypto.symbol.toUpperCase());
      initializePriceWebSocket(symbols);
      
      // Subscribe to price updates
      const subscription = priceUpdates.subscribe(update => {
        setCryptocurrencies(prevCryptos => {
          return prevCryptos.map(crypto => {
            if (crypto.symbol.toUpperCase() === update.symbol) {
              const priceChange = ((update.price - crypto.current_price) / crypto.current_price) * 100;
              return {
                ...crypto,
                current_price: update.price,
                price_change_percentage_24h: crypto.price_change_percentage_24h + priceChange,
                high_24h: Math.max(crypto.high_24h || 0, update.price),
                low_24h: Math.min(crypto.low_24h || Infinity, update.price)
              };
            }
            return crypto;
          });
        });
        setLastUpdate(new Date());
      });

      return () => {
        subscription.unsubscribe();
        cleanupWebSocket();
      };
    }
  }, [cryptocurrencies]);

  const filteredCryptocurrencies = cryptocurrencies
    .filter(crypto =>
      crypto.name.toLowerCase().includes(searchParams.query.toLowerCase()) ||
      crypto.symbol.toLowerCase().includes(searchParams.query.toLowerCase())
    )
    .sort((a, b) => {
      const multiplier = searchParams.sortDirection === 'desc' ? -1 : 1;
      const fieldA = a[searchParams.sortBy as keyof CryptoPrice];
      const fieldB = b[searchParams.sortBy as keyof CryptoPrice];
      return typeof fieldA === 'number' && typeof fieldB === 'number'
        ? (fieldA - fieldB) * multiplier
        : 0;
    });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-red-600">{error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col space-y-6 mb-8">
          <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Cryptocurrency Prices</h1>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search coins..."
                value={searchParams.query}
                onChange={(e) => setSearchParams(prev => ({ ...prev, query: e.target.value }))}
                className="pl-10 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 w-64"
              />
            </div>
          </div>
          </div>
          
          {/* Market Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {cryptocurrencies.slice(0, 1).map(crypto => (
              <React.Fragment key={crypto.id}>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <Activity className="h-5 w-5 text-indigo-600 mr-2" />
                    <div>
                      <p className="text-sm text-gray-500">BTC Dominance (Live)</p>
                      <p className="text-lg font-semibold">
                        {((crypto.market_cap / cryptocurrencies.reduce((sum, c) => sum + c.market_cap, 0)) * 100).toFixed(2)}%
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <BarChart2 className="h-5 w-5 text-indigo-600 mr-2" />
                    <div>
                      <p className="text-sm text-gray-500">Total Market Cap (Live)</p>
                      <p className="text-lg font-semibold">
                        ${(cryptocurrencies.reduce((sum, c) => sum + c.market_cap, 0) / 1e9).toFixed(2)}B
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <DollarSign className="h-5 w-5 text-indigo-600 mr-2" />
                    <div>
                      <p className="text-sm text-gray-500">24h Volume (Live)</p>
                      <p className="text-lg font-semibold">
                        ${(cryptocurrencies.reduce((sum, c) => sum + c.total_volume, 0) / 1e9).toFixed(2)}B
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    {crypto.price_change_percentage_24h >= 0 ? (
                      <TrendingUp className="h-5 w-5 text-green-600 mr-2" />
                    ) : (
                      <TrendingDown className="h-5 w-5 text-red-600 mr-2" />
                    )}
                    <div>
                      <p className="text-sm text-gray-500">Market Sentiment (Live)</p>
                      <p className={`text-lg font-semibold ${
                        crypto.price_change_percentage_24h >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {crypto.price_change_percentage_24h >= 0 ? 'Bullish' : 'Bearish'}
                      </p>
                    </div>
                    <div className="text-xs text-gray-500 mt-2">
                      Last update: {lastUpdate.toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Top Gainers and Losers */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Top Gainers */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="px-4 py-5 sm:px-6 bg-green-50">
              <h3 className="text-lg leading-6 font-medium text-green-800 flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                Today's Top Gainers
              </h3>
            </div>
            <div className="px-4 py-5 sm:p-6">
              <div className="flow-root">
                <ul className="-my-5 divide-y divide-gray-200">
                  {topMovers.gainers.map((coin) => (
                    <li key={coin.id} className="py-4">
                      <div className="flex items-center space-x-4">
                        <div className="flex-shrink-0">
                          <img className="h-8 w-8 rounded-full" src={coin.image} alt={coin.name} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {coin.name}
                          </p>
                          <p className="text-sm text-gray-500 truncate">
                            {coin.symbol.toUpperCase()}
                          </p>
                        </div>
                        <div>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            +{coin.price_change_percentage_24h.toFixed(2)}%
                          </span>
                        </div>
                        <div className="flex-shrink-0 text-sm text-gray-900">
                          ${coin.current_price.toLocaleString()}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Top Losers */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="px-4 py-5 sm:px-6 bg-red-50">
              <h3 className="text-lg leading-6 font-medium text-red-800 flex items-center">
                <TrendingDown className="h-5 w-5 mr-2" />
                Today's Top Losers
              </h3>
            </div>
            <div className="px-4 py-5 sm:p-6">
              <div className="flow-root">
                <ul className="-my-5 divide-y divide-gray-200">
                  {topMovers.losers.map((coin) => (
                    <li key={coin.id} className="py-4">
                      <div className="flex items-center space-x-4">
                        <div className="flex-shrink-0">
                          <img className="h-8 w-8 rounded-full" src={coin.image} alt={coin.name} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {coin.name}
                          </p>
                          <p className="text-sm text-gray-500 truncate">
                            {coin.symbol.toUpperCase()}
                          </p>
                        </div>
                        <div>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            {coin.price_change_percentage_24h.toFixed(2)}%
                          </span>
                        </div>
                        <div className="flex-shrink-0 text-sm text-gray-900">
                          ${coin.current_price.toLocaleString()}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  #
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  24h High/Low
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => setSearchParams(prev => ({
                    ...prev,
                    sortBy: 'current_price',
                    sortDirection: prev.sortDirection === 'desc' ? 'asc' : 'desc'
                  }))}
                >
                  <div className="flex items-center">
                    Price
                    {searchParams.sortBy === 'current_price' && (
                      searchParams.sortDirection === 'desc' ? 
                        <SortDesc className="ml-1 h-4 w-4" /> : 
                        <SortAsc className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => setSearchParams(prev => ({
                    ...prev,
                    sortBy: 'price_change_percentage_24h',
                    sortDirection: prev.sortDirection === 'desc' ? 'asc' : 'desc'
                  }))}
                >
                  <div className="flex items-center">
                    24h Change
                    {searchParams.sortBy === 'price_change_percentage_24h' && (
                      searchParams.sortDirection === 'desc' ? 
                        <SortDesc className="ml-1 h-4 w-4" /> : 
                        <SortAsc className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => setSearchParams(prev => ({
                    ...prev,
                    sortBy: 'market_cap',
                    sortDirection: prev.sortDirection === 'desc' ? 'asc' : 'desc'
                  }))}
                >
                  <div className="flex items-center">
                    Market Cap
                    {searchParams.sortBy === 'market_cap' && (
                      searchParams.sortDirection === 'desc' ? 
                        <SortDesc className="ml-1 h-4 w-4" /> : 
                        <SortAsc className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => setSearchParams(prev => ({
                    ...prev,
                    sortBy: 'total_volume',
                    sortDirection: prev.sortDirection === 'desc' ? 'asc' : 'desc'
                  }))}
                >
                  <div className="flex items-center">
                    Volume(24h)
                    {searchParams.sortBy === 'total_volume' && (
                      searchParams.sortDirection === 'desc' ? 
                        <SortDesc className="ml-1 h-4 w-4" /> : 
                        <SortAsc className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Watchlist
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  24h Chart
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredCryptocurrencies.map((coin, index) => (
                <tr key={coin.id} className="hover:bg-gray-50 cursor-pointer" onClick={() => navigate(`/crypto/${coin.id}`)}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {index + 1}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10">
                        <img className="h-10 w-10 rounded-full" src={coin.image} alt={coin.name} />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{coin.name}</div>
                        <div className="text-sm text-gray-500">{coin.symbol.toUpperCase()}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex flex-col">
                      <div className="flex items-center text-sm text-green-600">
                        <TrendingUp className="h-4 w-4 mr-1" />
                        ${coin.high_24h?.toLocaleString() ?? 'N/A'}
                      </div>
                      <div className="flex items-center text-sm text-red-600">
                        <TrendingDown className="h-4 w-4 mr-1" />
                        ${coin.low_24h?.toLocaleString() ?? 'N/A'}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${coin.current_price.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      coin.price_change_percentage_24h >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {coin.price_change_percentage_24h >= 0 ? '+' : ''}{coin.price_change_percentage_24h.toFixed(2)}%
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${coin.market_cap.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${coin.total_volume.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => toggleWatchlist(coin.id)}
                      className={`p-2 rounded-full hover:bg-gray-100 ${
                        watchlist.includes(coin.id) ? 'text-yellow-500' : 'text-gray-400'
                      }`}
                    >
                      <Star className="h-5 w-5" fill={watchlist.includes(coin.id) ? 'currentColor' : 'none'} />
                    </button>
                    <Link
                      to={`/crypto/${coin.id}`}
                      className="p-2 rounded-full hover:bg-gray-100"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ExternalLink className="h-5 w-5 text-gray-400" />
                    </Link>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="w-32 h-16">
                      <LivePriceChart
                        symbol={coin.symbol}
                        height="100%"
                        showAxes={false}
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
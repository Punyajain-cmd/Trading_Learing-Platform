import React, { useState, useEffect } from 'react';
import { getCryptoPrices, CryptoPrice } from '../lib/api';
import LivePriceChart from '../components/LivePriceChart';
import { Bell, Star, TrendingUp, TrendingDown, AlertCircle, Settings, Plus } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

interface PriceAlert {
  id: string;
  crypto_symbol: string;
  condition: 'above' | 'below';
  target_price: number;
  status: 'active' | 'triggered' | 'disabled';
}

export default function WatchlistPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [watchlist, setWatchlist] = useState<string[]>([]);
  const [watchedCoins, setWatchedCoins] = useState<CryptoPrice[]>([]);
  const [loading, setLoading] = useState(true);
  const [alerts, setAlerts] = useState<PriceAlert[]>([]);
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [selectedCoin, setSelectedCoin] = useState<string | null>(null);
  const [newAlert, setNewAlert] = useState({
    condition: 'above' as const,
    price: ''
  });
  const [showMessage, setShowMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    fetchWatchlist();
  }, [user]);

  const fetchWatchlist = async () => {
    try {
      // Fetch watchlist
      const { data: watchlistData, error: watchlistError } = await supabase
        .from('watchlist')
        .select('crypto_id')
        .eq('user_id', user?.id);

      if (watchlistError) throw watchlistError;
      const watchlistIds = watchlistData?.map(item => item.crypto_id) || [];
      setWatchlist(watchlistIds);

      // Fetch alerts
      const { data: alertsData, error: alertsError } = await supabase
        .from('price_alerts')
        .select('*')
        .eq('user_id', user?.id);

      if (alertsError) throw alertsError;
      setAlerts(alertsData || []);

      // Fetch crypto data
      const allCryptos = await getCryptoPrices();
      const watchedCryptos = allCryptos.filter(crypto => watchlistIds.includes(crypto.id));
      setWatchedCoins(watchedCryptos);
    } catch (error) {
      console.error('Error fetching watchlist:', error);
      setShowMessage({
        type: 'error',
        text: 'Failed to load watchlist. Please try again.'
      });
    } finally {
      setLoading(false);
    }
  };

  const removeFromWatchlist = async (cryptoId: string) => {
    try {
      const { error } = await supabase
        .from('watchlist')
        .delete()
        .eq('user_id', user?.id)
        .eq('crypto_id', cryptoId);

      if (error) throw error;

      setWatchlist(prev => prev.filter(id => id !== cryptoId));
      setWatchedCoins(prev => prev.filter(coin => coin.id !== cryptoId));
      
      setShowMessage({
        type: 'success',
        text: 'Removed from watchlist'
      });
    } catch (error) {
      console.error('Error removing from watchlist:', error);
      setShowMessage({
        type: 'error',
        text: 'Failed to remove from watchlist'
      });
    }
  };

  const createAlert = async () => {
    if (!selectedCoin || !newAlert.price) return;

    try {
      const { error } = await supabase
        .from('price_alerts')
        .insert([{
          user_id: user?.id,
          crypto_symbol: selectedCoin,
          condition: newAlert.condition,
          target_price: parseFloat(newAlert.price),
          status: 'active'
        }]);

      if (error) throw error;

      setShowMessage({
        type: 'success',
        text: 'Price alert created successfully'
      });
      setShowAlertModal(false);
      fetchWatchlist(); // Refresh alerts
    } catch (error) {
      console.error('Error creating alert:', error);
      setShowMessage({
        type: 'error',
        text: 'Failed to create price alert'
      });
    }
  };

  const deleteAlert = async (alertId: string) => {
    try {
      const { error } = await supabase
        .from('price_alerts')
        .delete()
        .eq('id', alertId);

      if (error) throw error;

      setAlerts(prev => prev.filter(alert => alert.id !== alertId));
      setShowMessage({
        type: 'success',
        text: 'Alert deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting alert:', error);
      setShowMessage({
        type: 'error',
        text: 'Failed to delete alert'
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Message Toast */}
        {showMessage && (
          <div className={`fixed top-4 right-4 z-50 rounded-lg shadow-lg p-4 ${
            showMessage.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}>
            <div className="flex items-center">
              {showMessage.type === 'success' ? (
                <TrendingUp className="h-5 w-5 mr-2" />
              ) : (
                <AlertCircle className="h-5 w-5 mr-2" />
              )}
              <p>{showMessage.text}</p>
            </div>
          </div>
        )}

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Your Watchlist</h1>
          <p className="mt-2 text-gray-600">
            Track your favorite cryptocurrencies and set price alerts
          </p>
        </div>

        {watchedCoins.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <Star className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Your watchlist is empty
            </h3>
            <p className="text-gray-500 mb-4">
              Add cryptocurrencies to your watchlist to track their prices and set alerts
            </p>
            <button
              onClick={() => navigate('/crypto')}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Cryptocurrencies
            </button>
          </div>
        ) : (
          <>
            {/* Price Alerts Section */}
            <div className="bg-white rounded-lg shadow-sm mb-8">
              <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900 flex items-center">
                  <Bell className="h-5 w-5 text-indigo-600 mr-2" />
                  Price Alerts
                </h3>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {alerts.map((alert) => (
                    <div key={alert.id} className="bg-gray-50 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium text-gray-900">{alert.crypto_symbol}</h4>
                          <p className="text-sm text-gray-500">
                            Alert when price goes {alert.condition}{' '}
                            ${alert.target_price.toLocaleString()}
                          </p>
                        </div>
                        <button
                          onClick={() => deleteAlert(alert.id)}
                          className="text-gray-400 hover:text-red-500"
                        >
                          <Settings className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="mt-2">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          alert.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                        }`}>
                          {alert.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Watched Coins */}
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {watchedCoins.map((coin) => (
                <div key={coin.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center">
                        <img
                          src={coin.image}
                          alt={coin.name}
                          className="h-10 w-10 rounded-full"
                        />
                        <div className="ml-4">
                          <h3 className="text-lg font-medium text-gray-900">{coin.name}</h3>
                          <p className="text-sm text-gray-500">{coin.symbol.toUpperCase()}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => removeFromWatchlist(coin.id)}
                        className="text-yellow-500 hover:text-yellow-600"
                      >
                        <Star className="h-6 w-6" fill="currentColor" />
                      </button>
                    </div>

                    <div className="mb-4">
                      <div className="flex justify-between items-baseline">
                        <p className="text-2xl font-bold text-gray-900">
                          ${coin.current_price.toLocaleString()}
                        </p>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          coin.price_change_percentage_24h >= 0
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {coin.price_change_percentage_24h >= 0 ? (
                            <TrendingUp className="h-4 w-4 mr-1" />
                          ) : (
                            <TrendingDown className="h-4 w-4 mr-1" />
                          )}
                          {coin.price_change_percentage_24h.toFixed(2)}%
                        </span>
                      </div>
                    </div>

                    <div className="h-32 mb-4">
                      <LivePriceChart
                        symbol={coin.symbol}
                        height="100%"
                        showAxes={false}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Market Cap</p>
                        <p className="font-medium text-gray-900">
                          ${coin.market_cap.toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-500">24h Volume</p>
                        <p className="font-medium text-gray-900">
                          ${coin.total_volume.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedCoin(coin.symbol);
                        setShowAlertModal(true);
                      }}
                      className="mt-4 w-full flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                    >
                      <Bell className="h-4 w-4 mr-2" />
                      Set Price Alert
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Price Alert Modal */}
        {showAlertModal && (
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Set Price Alert for {selectedCoin}
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Alert Condition
                  </label>
                  <select
                    value={newAlert.condition}
                    onChange={(e) => setNewAlert(prev => ({
                      ...prev,
                      condition: e.target.value as 'above' | 'below'
                    }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  >
                    <option value="above">Price goes above</option>
                    <option value="below">Price goes below</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Target Price ($)
                  </label>
                  <input
                    type="number"
                    value={newAlert.price}
                    onChange={(e) => setNewAlert(prev => ({
                      ...prev,
                      price: e.target.value
                    }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    placeholder="Enter price"
                    step="any"
                  />
                </div>
                <div className="flex justify-end space-x-3">
                  <button
                    onClick={() => setShowAlertModal(false)}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={createAlert}
                    className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
                  >
                    Create Alert
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
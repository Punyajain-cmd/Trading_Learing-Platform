import React from 'react';
import { Search, Book, MessageCircle, Shield, HelpCircle, Mail } from 'lucide-react';

export default function HelpCenterPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            How can we help you?
          </h1>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
            Find answers to common questions and learn how to make the most of Bitmore
          </p>
          
          {/* Search Bar */}
          <div className="mt-8 max-w-xl mx-auto">
            <div className="mt-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 pr-12 sm:text-sm border-gray-300 rounded-md"
                placeholder="Search for help articles..."
              />
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="mt-16">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: 'Getting Started',
                description: 'Learn the basics of trading and how to use our platform',
                icon: <Book className="h-6 w-6" />,
                topics: ['Platform Overview', 'Account Setup', 'Virtual Trading']
              },
              {
                title: 'Trading Guide',
                description: 'Understand trading mechanics and strategies',
                icon: <Shield className="h-6 w-6" />,
                topics: ['Basic Concepts', 'Risk Management', 'Technical Analysis']
              },
              {
                title: 'Account & Security',
                description: 'Manage your account settings and security',
                icon: <HelpCircle className="h-6 w-6" />,
                topics: ['Profile Settings', 'Security Features', 'Privacy Controls']
              }
            ].map((section) => (
              <div
                key={section.title}
                className="relative group bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600">
                      {section.icon}
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-medium text-gray-900">
                      {section.title}
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                      {section.description}
                    </p>
                  </div>
                </div>
                <div className="mt-4">
                  <ul className="space-y-2">
                    {section.topics.map((topic) => (
                      <li key={topic}>
                        <a
                          href="#"
                          className="text-sm text-indigo-600 hover:text-indigo-500 flex items-center"
                        >
                          <span className="mr-2">•</span>
                          {topic}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">
            Frequently Asked Questions
          </h2>
          <div className="space-y-4">
            {[
              {
                question: 'How do I start trading?',
                answer: "Sign up for an account, complete your profile, and you'll receive ₹10 Lakh in virtual money to start trading immediately."
              },
              {
                question: 'Is my virtual money real?',
                answer: 'No, the initial ₹10 Lakh is virtual money for practice. It allows you to learn trading without risking real money.'
              },
              {
                question: 'How do I participate in trading competitions?',
                answer: 'Visit the Live Games section to view and join available trading competitions. Each competition has its own rules and prize pool.'
              }
            ].map((faq, index) => (
              <div
                key={index}
                className="bg-white shadow rounded-lg overflow-hidden hover:shadow-md transition-shadow"
              >
                <div className="p-6">
                  <h3 className="text-lg font-medium text-gray-900">
                    {faq.question}
                  </h3>
                  <p className="mt-2 text-gray-600">
                    {faq.answer}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Contact Support */}
        <div className="mt-16 bg-indigo-700 rounded-2xl overflow-hidden shadow-xl">
          <div className="px-6 py-12 sm:px-12">
            <div className="lg:flex lg:items-center lg:justify-between">
              <div className="flex-1">
                <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
                  Still need help?
                </h2>
                <p className="mt-3 text-lg text-indigo-200">
                  Our support team is here to assist you 24/7
                </p>
              </div>
              <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
                <div className="inline-flex rounded-md shadow">
                  <a
                    href="mailto:support@tradinglearn.com"
                    className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-indigo-600 bg-white hover:bg-indigo-50"
                  >
                    <Mail className="h-5 w-5 mr-2" />
                    Contact Support
                  </a>
                </div>
                <div className="ml-3 inline-flex rounded-md shadow">
                  <a
                    href="#"
                    className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                  >
                    <MessageCircle className="h-5 w-5 mr-2" />
                    Live Chat
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
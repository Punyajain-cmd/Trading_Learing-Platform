import React from 'react';
import { Shield, Lock, Eye, UserCheck, Database, Server } from 'lucide-react';

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            Privacy Policy
          </h1>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
            Your privacy is important to us. Learn how we collect, use, and protect your data.
          </p>
        </div>

        {/* Last Updated */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </div>

        {/* Key Points */}
        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {[
            {
              icon: <Shield className="h-6 w-6" />,
              title: 'Data Protection',
              description: 'We employ industry-standard security measures to protect your personal information.'
            },
            {
              icon: <Lock className="h-6 w-6" />,
              title: 'Secure Trading',
              description: 'All trading activities are encrypted and protected using advanced security protocols.'
            },
            {
              icon: <Eye className="h-6 w-6" />,
              title: 'Transparency',
              description: "We're clear about what data we collect and how we use it to improve your experience."
            },
            {
              icon: <UserCheck className="h-6 w-6" />,
              title: 'User Control',
              description: 'You have full control over your personal data and can request its deletion at any time.'
            },
            {
              icon: <Database className="h-6 w-6" />,
              title: 'Data Storage',
              description: 'Your data is stored securely in encrypted databases with regular backups.'
            },
            {
              icon: <Server className="h-6 w-6" />,
              title: 'Limited Access',
              description: 'Only authorized personnel have access to user data on a need-to-know basis.'
            }
          ].map((point) => (
            <div
              key={point.title}
              className="relative bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600">
                    {point.icon}
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">
                    {point.title}
                  </h3>
                  <p className="mt-2 text-sm text-gray-500">
                    {point.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Detailed Policy Sections */}
        <div className="mt-16 space-y-16">
          {[
            {
              title: 'Information We Collect',
              content: `We collect information that you provide directly to us, including:
              • Personal information (name, email, phone number)
              • Account credentials
              • Trading preferences and history
              • Device and browser information
              • Usage data and analytics`
            },
            {
              title: 'How We Use Your Information',
              content: `Your information helps us:
              • Provide and improve our services
              • Personalize your experience
              • Process your transactions
              • Send important updates and notifications
              • Maintain platform security
              • Comply with legal obligations`
            },
            {
              title: 'Data Sharing and Disclosure',
              content: `We may share your information with:
              • Service providers and partners
              • Legal authorities when required
              • Other users (only public profile information)
              We never sell your personal data to third parties.`
            },
            {
              title: 'Your Rights and Choices',
              content: `You have the right to:
              • Access your personal data
              • Correct inaccurate information
              • Request data deletion
              • Opt-out of marketing communications
              • Export your data
              Contact us to exercise these rights.`
            }
          ].map((section) => (
            <div key={section.title} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="px-6 py-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">
                  {section.title}
                </h2>
                <div className="prose prose-indigo">
                  <p className="whitespace-pre-line text-gray-600">
                    {section.content}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Contact Section */}
        <div className="mt-16 bg-indigo-50 rounded-2xl overflow-hidden">
          <div className="px-6 py-12 sm:px-12">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900">
                Questions About Privacy?
              </h2>
              <p className="mt-4 text-lg text-gray-500">
                If you have any questions about our privacy policy or how we handle your data,
                please don't hesitate to contact us.
              </p>
              <div className="mt-8">
                <a
                  href="mailto:privacy@tradinglearn.com"
                  className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                >
                  Contact Privacy Team
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import { Subject } from 'rxjs';

// WebSocket connection for real-time price updates
const WS_URL = 'wss://ws.coincap.io/prices?assets=';
let wsInstance: WebSocket | null = null;
let reconnectAttempts = 0;
const INITIAL_RECONNECT_DELAY = 2000;
const MAX_RECONNECT_ATTEMPTS = 10;
const PING_INTERVAL = 30000; // 30 seconds
const CONNECTION_TIMEOUT = 10000; // 10 seconds

let reconnectTimer: NodeJS.Timeout | null = null;
let subscribeTimer: NodeJS.Timeout | null = null;
let pingInterval: NodeJS.Timeout | null = null;
let connectionTimeout: NodeJS.Timeout | null = null;
let isIntentionalClose = false;
let currentSymbols: string[] = [];
let isConnecting = false;

// Price update stream
export const priceUpdates = new Subject<{
  symbol: string;
  price: number;
  timestamp: number;
}>();

// Store historical price data
const priceHistory: { [key: string]: { timestamp: number; price: number; }[] } = {};
const MAX_HISTORY_LENGTH = 100;

// Get initial price for a symbol
function getInitialPrice(symbol: string): number {
  const prices: { [key: string]: number } = {
    // Core assets that work reliably with CoinCap WebSocket
    'BTC': 42000,
    'ETH': 2300,
    'BNB': 310,
    'SOL': 100,
    'ADA': 0.5,
    'DOT': 6.7,
    'LINK': 14,
    'MATIC': 0.9,
    'AVAX': 34,
    'UNI': 5.6
  };
  return prices[symbol.toUpperCase()] || 100;
}

// Initialize WebSocket connection
export const initializePriceWebSocket = (symbols: string[]) => {
  if (isConnecting) {
    console.log('Already attempting to connect, skipping...');
    return;
  }
  
  // Map symbols to CoinCap compatible format
  const symbolMapping: { [key: string]: string } = {
    'BTC': 'bitcoin',
    'ETH': 'ethereum',
    'SOL': 'solana',
    'ADA': 'cardano',
    'DOT': 'polkadot',
    'LINK': 'chainlink',
    'MATIC': 'matic-network',
    'AVAX': 'avalanche-2',
    'UNI': 'uniswap'
  };
  
  // Only use core assets that work reliably with CoinCap WebSocket
  const validSymbols = symbols.filter(symbol => 
    Object.keys(symbolMapping).includes(symbol.toUpperCase())
  );
  
  if (validSymbols.length === 0) {
    console.log('No valid symbols to subscribe to');
    generateInitialMockData(symbols);
    return;
  }

  isConnecting = true;
  currentSymbols = validSymbols;

  if (wsInstance?.readyState === WebSocket.OPEN) {
    isIntentionalClose = true;
    wsInstance.close();
    return;
  }

  const connectWebSocket = () => {
    try {
      isIntentionalClose = false;
      
      // Create URL with mapped asset names
      const assetsParam = validSymbols
        .map(s => symbolMapping[s.toUpperCase()])
        .filter(Boolean)
        .join(',');
      
      if (!assetsParam) {
        console.log('No valid assets to connect to');
        generateInitialMockData(symbols);
        isConnecting = false;
        return;
      }
      
      const wsUrlWithAssets = `${WS_URL}${assetsParam}`;
      console.log('Connecting to WebSocket:', wsUrlWithAssets);
      
      wsInstance = new WebSocket(wsUrlWithAssets);

      wsInstance.onerror = (error) => {
        console.warn('WebSocket error:', error);
        
        // Generate mock data while attempting to reconnect
        generateInitialMockData(validSymbols);
        
        // Attempt reconnection if not intentionally closed
        if (!isIntentionalClose && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
          reconnectAttempts++;
          if (reconnectTimer) clearTimeout(reconnectTimer);
          
          const delay = INITIAL_RECONNECT_DELAY * Math.pow(2, reconnectAttempts - 1);
          console.log(`Attempting reconnect ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS} in ${delay}ms...`);
          
          reconnectTimer = setTimeout(() => {
            connectWebSocket();
          }, delay);
        } else if (!isIntentionalClose) {
          console.log('Max reconnection attempts reached, falling back to mock data');
          generateInitialMockData(validSymbols);
        }
      };
      
      connectionTimeout = setTimeout(() => {
        if (wsInstance?.readyState !== WebSocket.OPEN) {
          console.log('WebSocket connection timeout, retrying...');
          wsInstance?.close();
        }
      }, CONNECTION_TIMEOUT);
    
      wsInstance.onopen = () => {
        isConnecting = false;
        if (connectionTimeout) {
          clearTimeout(connectionTimeout);
          connectionTimeout = null;
        }
        reconnectAttempts = 0;
        if (reconnectTimer) {
          clearTimeout(reconnectTimer);
          reconnectTimer = null;
        }

        console.log('WebSocket connected successfully');
        
        // Setup ping interval to keep connection alive
        if (pingInterval) clearInterval(pingInterval);
        pingInterval = setInterval(() => {
          if (wsInstance?.readyState === WebSocket.OPEN) {
            wsInstance.send(JSON.stringify({ type: 'ping' }));
          }
        }, PING_INTERVAL);

        // Clear any existing subscribe timer
        if (subscribeTimer) {
          clearTimeout(subscribeTimer);
        }

        // Add a small delay before subscribing to ensure connection is stable
        subscribeTimer = setTimeout(() => {
          if (!wsInstance || wsInstance.readyState !== WebSocket.OPEN) return;
          console.log('Connected to CoinCap WebSocket');
        }, 1000);

        // Generate initial data while waiting for real updates
        generateInitialMockData(validSymbols);
      };
    
      // Handle incoming messages
      wsInstance.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          // Handle CoinCap price updates
          Object.entries(data).forEach(([asset, price]) => {
            if (typeof price === 'string') {
              const parsedPrice = parseFloat(price);
              if (!isNaN(parsedPrice)) {
                // Convert asset name back to symbol
                const symbol = Object.entries(symbolMapping).find(([_, value]) => value === asset)?.[0];
                if (!symbol) return;
                
                const update = {
                  symbol,
                  price: parsedPrice,
                  timestamp: Date.now()
                };

                // Update price history
                if (!priceHistory[update.symbol]) {
                  priceHistory[update.symbol] = [];
                }
                priceHistory[update.symbol].push({
                  timestamp: update.timestamp,
                  price: update.price
                });

                // Keep history length in check
                if (priceHistory[update.symbol].length > MAX_HISTORY_LENGTH) {
                  priceHistory[update.symbol].shift();
                }

                // Emit update
                priceUpdates.next(update);
              }
            }
          });
        } catch (error) {
          console.error('Error processing WebSocket message:', error);
        }
      };
    
      wsInstance.onclose = (event) => {
        console.log(`WebSocket closed with code ${event.code}. Clean: ${event.wasClean}`);
        wsInstance = null;
        isConnecting = false;
        
        if (pingInterval) {
          clearInterval(pingInterval);
          pingInterval = null;
        }
        
        if (connectionTimeout) {
          clearTimeout(connectionTimeout);
          connectionTimeout = null;
        }
        
        if (subscribeTimer) {
          clearTimeout(subscribeTimer);
          subscribeTimer = null;
        }

        // Don't reconnect if the close was intentional
        if (!isIntentionalClose && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
          reconnectAttempts++;
          const delay = INITIAL_RECONNECT_DELAY * Math.pow(2, reconnectAttempts - 1);
          reconnectTimer = setTimeout(() => {
            console.log(`Attempting reconnect ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS} in ${delay}ms...`);
            connectWebSocket();
          }, delay);
        } else {
          if (!isIntentionalClose) {
            console.log('Max reconnection attempts reached');
            // Instead of erroring, use fallback data
            generateInitialMockData(currentSymbols);
            // Reset reconnect attempts after some time to allow future reconnection attempts
            setTimeout(() => {
              reconnectAttempts = 0;
            }, 60000);
          }
        }
      };
    } catch (error) {
      console.error('Error initializing WebSocket:', error);
      isConnecting = false;
      // Generate mock data on connection error
      generateInitialMockData(validSymbols);
    }
  };

  // Start the initial connection
  connectWebSocket();
};

// Cleanup WebSocket connection
export const cleanupWebSocket = () => {
  isConnecting = false;
  if (wsInstance) {
    isIntentionalClose = true;
    if (pingInterval) {
      clearInterval(pingInterval);
      pingInterval = null;
    }
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    if (connectionTimeout) {
      clearTimeout(connectionTimeout);
      connectionTimeout = null;
    }
    if (subscribeTimer) {
      clearTimeout(subscribeTimer);
      subscribeTimer = null;
    }
    wsInstance.close();
    wsInstance = null;
    reconnectAttempts = 0;
    currentSymbols = [];
  }
};

// Generate initial mock data for all symbols
function generateInitialMockData(symbols: string[]) {
  const now = Date.now();
  symbols.forEach(symbol => {
    if (!priceHistory[symbol]) {
      const initialPrice = getInitialPrice(symbol);
      priceHistory[symbol] = Array.from({ length: 50 }, (_, i) => ({
        timestamp: now - (19 - i) * 1000,
        price: initialPrice * (1 + (Math.random() - 0.5) * 0.01)
      }));
    }
  });
}

// Get price history for a symbol
export const getPriceHistory = (symbol: string) => {
  return priceHistory[symbol] || [];
};

// Cryptocurrency API endpoints
const COINGECKO_API_BASE = 'https://api.coingecko.com/api/v3';
const CACHE_DURATION = 300000; // 5 minute cache to avoid rate limits
const FETCH_TIMEOUT = 8000; // 8 seconds timeout

// Retry configuration
const MAX_RETRIES = 3;
const RETRY_DELAY = 2000; // 2 seconds

// Number of top gainers/losers to return
const TOP_MOVERS_COUNT = 5;

// Cache with type safety
let priceCache: {
  data: CryptoPrice[] | null;
  timestamp: number;
} = {
  data: null,
  timestamp: 0
};

// Helper function to delay execution
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Helper function to validate price data
const validatePriceData = (data: any[]): boolean => {
  return data.every(item => 
    typeof item.id === 'string' &&
    typeof item.symbol === 'string' &&
    typeof item.name === 'string' &&
    typeof item.current_price === 'number' &&
    typeof item.market_cap === 'number' &&
    typeof item.total_volume === 'number' &&
    typeof item.price_change_percentage_24h === 'number' &&
    typeof item.image === 'string'
  );
};

// Helper function to make API request with retries
async function fetchWithRetry(url: string, options: RequestInit, retries = MAX_RETRIES): Promise<Response> {
  try {
    const response = await fetch(url, options);
    const remaining = response.headers.get('x-ratelimit-remaining');
    
    if (!response.ok) {
      if ((response.status === 429 || (remaining && parseInt(remaining) < 1)) && retries > 0) {
        console.warn(`Rate limit hit, retrying in ${RETRY_DELAY}ms... (${retries} retries left)`);
        await delay(RETRY_DELAY);
        return fetchWithRetry(url, options, retries - 1);
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    return response;
  } catch (error) {
    if (retries > 0 && error instanceof Error && error.name !== 'AbortError') {
      console.warn(`Request failed, retrying in ${RETRY_DELAY}ms... (${retries} retries left)`, error);
      await delay(RETRY_DELAY);
      return fetchWithRetry(url, options, retries - 1);
    }
    throw error;
  }
}

export interface CryptoPrice {
  id: string;
  symbol: string;
  name: string;
  current_price: number;
  market_cap: number;
  total_volume: number;
  price_change_percentage_24h: number;
  high_24h: number;
  low_24h: number;
  circulating_supply: number;
  max_supply: number | null;
  ath: number;
  ath_change_percentage: number;
  image: string;
}

export interface CryptoHistoricalData {
  prices: [number, number][];
  market_caps: [number, number][];
  total_volumes: [number, number][];
}

export async function getCryptoPrices(): Promise<CryptoPrice[]> {
  try {
    // Check cache first
    const now = Date.now();
    const cacheValid = priceCache.data && 
                      Array.isArray(priceCache.data) && 
                      priceCache.data.length > 0 && 
                      now - priceCache.timestamp < CACHE_DURATION &&
                      validatePriceData(priceCache.data);
                      
    if (cacheValid) {
      console.log('Using cached crypto prices');
      return priceCache.data;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      controller.abort();
      console.warn('Fetch timeout, using fallback data');
    }, FETCH_TIMEOUT);

    try {
      const response = await fetchWithRetry(`${COINGECKO_API_BASE}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&sparkline=false`, {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        },
        signal: controller.signal
      });
      
      if (!response.ok) {
        if (response.status === 429) {
          console.warn('Rate limit exceeded, using fallback data');
          throw new Error('Rate limit exceeded');
        }

        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (!Array.isArray(data) || !data.length) {
        throw new Error('Invalid data format received');
      }
    
      // Validate data structure using helper function
      const validData = validatePriceData(data);

      if (!validData) {
        console.warn('Invalid data structure received, using fallback data');
        return FALLBACK_PRICES;
      }
      
      console.log('Successfully fetched fresh crypto prices');

      // Update cache with validated data and current timestamp
      priceCache = {
        data,
        timestamp: now
      };

      return data;
    } finally {
      clearTimeout(timeoutId);
    }
  } catch (error) {
    console.error('Error fetching crypto prices:', error);
    
    // Use cached data if available and valid
    const cacheValid = priceCache.data && 
                      Array.isArray(priceCache.data) && 
                      priceCache.data.length > 0 && 
                      Date.now() - priceCache.timestamp < CACHE_DURATION * 2 &&
                      validatePriceData(priceCache.data);
                      
    if (cacheValid) {
      console.log('Using cached data after fetch error');
      return priceCache.data;
    }
    
    // Use fallback data as last resort
    console.log('Using fallback data');
    return FALLBACK_PRICES;
  }
}

export async function getTopGainersLosers(): Promise<{
  gainers: CryptoPrice[];
  losers: CryptoPrice[];
}> {
  try {
    const allPrices = await getCryptoPrices();
    
    if (!allPrices || allPrices.length === 0) {
      console.warn('No price data available for top gainers/losers');
      return { gainers: [], losers: [] };
    }

    const sorted = [...allPrices].sort(
      (a, b) => Math.abs(b.price_change_percentage_24h) - Math.abs(a.price_change_percentage_24h)
    );
    
    const gainers = sorted
      .filter(coin => coin.price_change_percentage_24h > 0)
      .slice(0, TOP_MOVERS_COUNT);
    
    const losers = sorted
      .filter(coin => coin.price_change_percentage_24h < 0)
      .slice(0, TOP_MOVERS_COUNT);

    return { gainers, losers };
  } catch (error) {
    console.error('Error getting top gainers/losers:', error);
    return { gainers: [], losers: [] };
  }
}

// Fallback data for when API fails
const FALLBACK_PRICES: CryptoPrice[] = [
  {
    id: 'bitcoin',
    symbol: 'btc',
    name: 'Bitcoin',
    current_price: getInitialPrice('BTC'),
    market_cap: 853492847632,
    total_volume: 31245678901,
    price_change_percentage_24h: (Math.random() * 2 - 1) * 5, // Random -5% to +5%
    high_24h: getInitialPrice('BTC') * 1.05,
    low_24h: getInitialPrice('BTC') * 0.95,
    circulating_supply: 19000000,
    max_supply: 21000000,
    ath: 69000,
    ath_change_percentage: -37,
    image: 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png'
  },
  {
    id: 'ethereum',
    symbol: 'eth',
    name: 'Ethereum',
    current_price: getInitialPrice('ETH'),
    market_cap: 276543210987,
    total_volume: 18765432109,
    price_change_percentage_24h: (Math.random() * 2 - 1) * 5, // Random -5% to +5%
    high_24h: getInitialPrice('ETH') * 1.05,
    low_24h: getInitialPrice('ETH') * 0.95,
    circulating_supply: 120000000,
    max_supply: null,
    ath: 4800,
    ath_change_percentage: -52,
    image: 'https://assets.coingecko.com/coins/images/279/large/ethereum.png'
  },
  {
    id: 'solana',
    symbol: 'sol',
    name: 'Solana',
    current_price: getInitialPrice('SOL'),
    market_cap: 45678901234,
    total_volume: 2345678901,
    price_change_percentage_24h: (Math.random() * 2 - 1) * 5, // Random -5% to +5%
    high_24h: getInitialPrice('SOL') * 1.05,
    low_24h: getInitialPrice('SOL') * 0.95,
    circulating_supply: 400000000,
    max_supply: null,
    ath: 260,
    ath_change_percentage: -62,
    image: 'https://assets.coingecko.com/coins/images/4128/large/solana.png'
  }
];